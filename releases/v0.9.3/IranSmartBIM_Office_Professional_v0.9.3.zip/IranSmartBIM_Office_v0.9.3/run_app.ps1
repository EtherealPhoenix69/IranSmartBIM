$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (Test-Path '.\dist\IranSmartBIM.exe') { Start-Process '.\dist\IranSmartBIM.exe' } else { Write-Host 'ابتدا build_windows.ps1 را اجرا کنید.' -ForegroundColor Yellow }
