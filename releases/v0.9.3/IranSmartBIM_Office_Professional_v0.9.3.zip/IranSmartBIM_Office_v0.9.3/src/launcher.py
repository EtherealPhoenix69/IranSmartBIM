"""Stable PyInstaller entry point; keeps package imports intact."""
from iran_smart_bim.app import main

if __name__ == "__main__":
    main()
