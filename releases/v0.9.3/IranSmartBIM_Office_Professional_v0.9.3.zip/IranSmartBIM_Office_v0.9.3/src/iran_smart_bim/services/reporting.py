"""Cross-platform PDF reports with Persian-friendly font discovery."""
from __future__ import annotations

from pathlib import Path
import os

from PIL import Image, ImageDraw, ImageFont


def _find_font(bold: bool = False) -> str | None:
    candidates = []
    if os.name == "nt":
        candidates += [
            r"C:\Windows\Fonts\tahomabd.ttf" if bold else r"C:\Windows\Fonts\tahoma.ttf",
            r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
            r"C:\Windows\Fonts\segoeuib.ttf" if bold else r"C:\Windows\Fonts\segoeui.ttf",
        ]
    candidates += [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return candidate
    return None


def _rtl(value) -> str:
    text = str(value if value is not None else "")
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(text))
    except Exception:
        return text


def _font(path: str | None, size: int):
    if path:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            pass
    return ImageFont.load_default()


def pdf_report(path, project_name, rows, total, statement=None):
    try:
        from reportlab.pdfgen import canvas
        from reportlab.lib.pagesizes import A4, landscape
    except ModuleNotFoundError as exc:
        raise RuntimeError("برای ساخت PDF ابتدا اجرا کنید: python -m pip install reportlab") from exc

    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    regular = _font(_find_font(False), 16)
    bold = _font(_find_font(True), 20)

    headers = ["کد", "شرح", "فصل", "واحد", "مقدار", "قیمت واحد", "پایه", "پرت", "حمل", "سایر", "ضرایب", "تعدیل", "نهایی"]
    widths = [95, 280, 150, 60, 90, 115, 115, 95, 95, 100, 105, 100, 125]
    row_h, header_h, title_h = 42, 42, 58
    width = sum(widths)
    page_w, page_h = landscape(A4)
    margin = 18
    scale = min((page_w - margin * 2) / width, 1.0)
    scaled_w = width * scale
    scaled_row = row_h * scale
    scaled_header = header_h * scale
    scaled_title = title_h * scale
    rows_per_page = max(1, int((page_h - 2 * margin - scaled_title - scaled_header - 24) / scaled_row))
    pages = [rows[i:i + rows_per_page] for i in range(0, len(rows), rows_per_page)] or [[]]

    temp_images = []
    c = canvas.Canvas(str(output), pagesize=landscape(A4))
    for page_no, page_rows in enumerate(pages, 1):
        page_height_px = int((page_h - 2 * margin) / scale)
        page_img = Image.new("RGB", (width, page_height_px), "white")
        d = ImageDraw.Draw(page_img)
        title = _rtl(f"IranSmartBIM | {statement or 'گزارش متره و برآورد'} | {project_name}")
        d.text((width // 2, 12), title, font=bold, fill="#17365D", anchor="mm")
        d.text((width - 12, 38), _rtl(f"صفحه {page_no} از {len(pages)}"), font=regular, fill="#60758A", anchor="ra")
        y = title_h
        d.rectangle((0, y, width, y + row_h), fill="#17365D")
        x = 0
        for h, w in zip(headers, widths):
            d.text((x + w / 2, y + row_h / 2), _rtl(h), font=regular, fill="white", anchor="mm")
            x += w
        y += row_h
        for idx, line in enumerate(page_rows):
            if idx % 2:
                d.rectangle((0, y, width, y + row_h), fill="#F4F7FB")
            vals = [
                line.get("item_code", ""), line.get("description", ""), line.get("chapter_title", ""),
                line.get("unit", ""), f"{float(line.get('quantity', 0)):,.3f}",
                f"{float(line.get('unit_price', 0)):,.0f}", f"{float(line.get('base', 0)):,.0f}",
                f"{float(line.get('waste', 0)):,.0f}", f"{float(line.get('transport', 0)):,.0f}",
                f"{float(line.get('other_direct', 0)):,.0f}", f"{float(line.get('coefficient_amount', 0)):,.0f}",
                f"{float(line.get('escalation', 0)):,.0f}", f"{float(line.get('final', 0)):,.0f}",
            ]
            x = 0
            for col, (value, w) in enumerate(zip(vals, widths)):
                d.rectangle((x, y, x + w, y + row_h), outline="#B7C0CC")
                value = _rtl(value)
                # Keep table cells readable and avoid overflow in long descriptions.
                if col in (1, 2) and len(value) > 34:
                    value = value[:31] + "…"
                d.text((x + w / 2, y + row_h / 2), value, font=regular, fill="#1F2937", anchor="mm")
                x += w
            y += row_h
        d.rectangle((0, y, width, y + row_h), fill="#D9E2F3")
        d.text((width * .79, y + row_h / 2), _rtl("جمع کل"), font=bold, fill="#17365D", anchor="mm")
        d.text((width * .93, y + row_h / 2), f"{float(total):,.0f} ریال", font=bold, fill="#17365D", anchor="mm")
        image_path = output.with_name(f"{output.stem}_page_{page_no}.png")
        page_img.save(image_path)
        temp_images.append(image_path)
        c.drawImage(str(image_path), (page_w - scaled_w) / 2, margin, width=scaled_w, height=page_img.height * scale, preserveAspectRatio=True)
        c.showPage()
    c.save()
    for image_path in temp_images:
        image_path.unlink(missing_ok=True)
    return output
