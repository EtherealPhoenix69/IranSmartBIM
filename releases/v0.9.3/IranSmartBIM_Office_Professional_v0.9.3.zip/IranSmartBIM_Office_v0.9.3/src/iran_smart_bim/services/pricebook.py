def search_items(con, year, discipline, text='', chapter_code='', limit=5000):
    params=[int(year),discipline]
    sql='''SELECT pi.id,pi.code,pi.description,pi.unit,pi.unit_price,pi.price_status,
                  pi.source,pi.material_share,pi.labor_share,pi.equipment_share,
                  c.code chapter_code,c.title chapter_title
           FROM price_items pi
           JOIN chapters c ON c.id=pi.chapter_id
           JOIN price_lists pl ON pl.id=c.price_list_id
           WHERE pl.year=? AND pl.discipline=?'''
    if text.strip():
        q='%'+text.strip()+'%'
        sql+=' AND (pi.code LIKE ? OR pi.description LIKE ?)'
        params += [q,q]
    if chapter_code:
        sql+=' AND c.code=?'; params.append(chapter_code)
    sql+=' ORDER BY CAST(c.code AS INTEGER), pi.code, pi.description LIMIT ?'
    params.append(int(limit))
    return con.execute(sql,params).fetchall()

def get_item(con, item_id):
    return con.execute('''SELECT pi.*,c.code chapter_code,c.title chapter_title,
                                 pl.year,pl.discipline,pl.title price_list_title
                          FROM price_items pi
                          JOIN chapters c ON c.id=pi.chapter_id
                          JOIN price_lists pl ON pl.id=c.price_list_id
                          WHERE pi.id=?''',(int(item_id),)).fetchone()

def update_analysis(con, item_id, material_share, labor_share, equipment_share):
    vals=(float(material_share),float(labor_share),float(equipment_share))
    con.execute('''UPDATE price_items
                   SET material_share=?, labor_share=?, equipment_share=?
                   WHERE id=?''',(*vals,int(item_id)))
    con.commit()

def price_lists(con):
    return con.execute('SELECT * FROM price_lists ORDER BY year DESC,discipline').fetchall()

def chapters(con, price_list_id):
    return con.execute('SELECT * FROM chapters WHERE price_list_id=? ORDER BY CAST(code AS INTEGER)',(price_list_id,)).fetchall()
