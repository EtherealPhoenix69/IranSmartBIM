import csv
def import_price_csv(con,path):
    count=0
    with open(path,'r',encoding='utf-8-sig',newline='') as f:
        for r in csv.DictReader(f):
            year=int(r['year']); disc=r['discipline'].strip()
            con.execute('INSERT INTO price_lists(year,discipline,title,bulletin_no,issue_date,source) VALUES(?,?,?,?,?,?) ON CONFLICT(year,discipline) DO UPDATE SET title=excluded.title,bulletin_no=excluded.bulletin_no,issue_date=excluded.issue_date,source=excluded.source',(year,disc,r.get('title') or f'فهرست‌بها {year} - {disc}',r.get('bulletin_no',''),r.get('issue_date',''),r.get('source','')))
            pl=con.execute('SELECT id FROM price_lists WHERE year=? AND discipline=?',(year,disc)).fetchone()[0]; cc=r['chapter'].strip(); ct=r.get('chapter_title') or cc
            con.execute('INSERT INTO chapters(price_list_id,code,title) VALUES(?,?,?) ON CONFLICT(price_list_id,code) DO UPDATE SET title=excluded.title',(pl,cc,ct)); ch=con.execute('SELECT id FROM chapters WHERE price_list_id=? AND code=?',(pl,cc)).fetchone()[0]
            desc=r['description'].strip(); code=r['code'].strip(); unit=r['unit'].strip(); price=float(r.get('unit_price') or 0)
            status='available' if price > 0 else 'requires_manual_price'
            con.execute('''INSERT INTO price_items(chapter_id,code,description,unit,unit_price,labor_share,material_share,equipment_share,source,price_status) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(chapter_id,code,description) DO UPDATE SET unit=excluded.unit,unit_price=excluded.unit_price,labor_share=excluded.labor_share,material_share=excluded.material_share,equipment_share=excluded.equipment_share,source=excluded.source,price_status=excluded.price_status''',(ch,code,desc,unit,price,float(r.get('labor_share') or 0),float(r.get('material_share') or 0),float(r.get('equipment_share') or 0),r.get('source',''),status)); count+=1
    con.commit(); return count
def import_adjustment_csv(con,path):
    count=0
    with open(path,'r',encoding='utf-8-sig',newline='') as f:
        for r in csv.DictReader(f):
            con.execute('''INSERT INTO escalation_indices(year,period,discipline,index_type,base_index,current_index,coefficient,source) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(year,period,discipline,index_type) DO UPDATE SET base_index=excluded.base_index,current_index=excluded.current_index,coefficient=excluded.coefficient,source=excluded.source''',(int(r['year']),r['period'].strip(),r['discipline'].strip(),r.get('index_type','general').strip(),float(r.get('base_index') or 0),float(r.get('current_index') or 0),float(r.get('coefficient') or 0),r.get('source',''))); count+=1
    con.commit(); return count
