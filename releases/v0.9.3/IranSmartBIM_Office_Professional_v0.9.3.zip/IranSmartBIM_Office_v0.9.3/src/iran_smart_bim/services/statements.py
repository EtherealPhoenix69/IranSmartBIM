"""Interim statement service with estimate-consistent calculations and snapshots."""
from __future__ import annotations

import json

from ..calculation import calculate_statement_line


def _project_coefficients(con, project_id):
    rows = con.execute('''
        SELECT c.name,c.code,c.kind,COALESCE(pc.value,c.value) AS value,
               c.basis,pc.sequence,pc.enabled
        FROM project_coefficients pc
        JOIN coefficients c ON c.id=pc.coefficient_id
        WHERE pc.project_id=? AND pc.enabled=1
        ORDER BY pc.sequence,c.id
    ''', (int(project_id),)).fetchall()
    return [dict(row) for row in rows]


def create_statement(
    con,
    project_id,
    statement_no,
    period,
    adjustment_factor=0,
    description='',
    coefficients=None,
    current_quantities=None,
):
    """Create or regenerate a draft statement.

    Regenerating a statement that has later statements is blocked to prevent
    silently invalidating their previous-quantity chain.
    """
    project_id = int(project_id)
    statement_no = int(statement_no)
    if statement_no < 1:
        raise ValueError('statement_no must be positive')
    if not str(period).strip():
        raise ValueError('period is required')

    later = con.execute(
        'SELECT statement_no FROM statements WHERE project_id=? AND statement_no>? ORDER BY statement_no LIMIT 1',
        (project_id, statement_no),
    ).fetchone()
    if later:
        raise ValueError(
            f'صورت‌وضعیت شماره {statement_no} دارای دوره‌های بعدی است؛ '
            'برای جلوگیری از خراب‌شدن زنجیره مقادیر قبلی، ابتدا صورت‌وضعیت‌های بعدی را حذف/اصلاح کنید.'
        )

    coefficient_rows = [dict(row) for row in (coefficients if coefficients is not None else _project_coefficients(con, project_id))]
    coefficient_json = json.dumps(coefficient_rows, ensure_ascii=False)
    adjustment_factor = float(adjustment_factor)

    with con:
        con.execute('''
            INSERT INTO statements(project_id,statement_no,period,status,description,adjustment_factor,coefficients_snapshot_json)
            VALUES(?,?,?,?,?,?,?)
            ON CONFLICT(project_id,statement_no) DO UPDATE SET
              period=excluded.period, description=excluded.description,
              adjustment_factor=excluded.adjustment_factor,
              coefficients_snapshot_json=excluded.coefficients_snapshot_json
        ''', (project_id, statement_no, str(period).strip(), 'draft', description, adjustment_factor, coefficient_json))
        statement_id = con.execute(
            'SELECT id FROM statements WHERE project_id=? AND statement_no=?',
            (project_id, statement_no),
        ).fetchone()['id']
        previous = con.execute(
            'SELECT id FROM statements WHERE project_id=? AND statement_no<? ORDER BY statement_no DESC LIMIT 1',
            (project_id, statement_no),
        ).fetchone()
        previous_id = previous['id'] if previous else None
        con.execute('DELETE FROM statement_lines WHERE statement_id=?', (statement_id,))

        total = 0.0
        takeoff_rows = con.execute(
            'SELECT * FROM takeoff_lines WHERE project_id=? ORDER BY id', (project_id,)
        ).fetchall()
        for takeoff in takeoff_rows:
            previous_qty = 0.0
            if previous_id is not None:
                prior = con.execute(
                    'SELECT quantity_to_date,amount_to_date FROM statement_lines WHERE statement_id=? AND takeoff_line_id=?',
                    (previous_id, takeoff['id']),
                ).fetchone()
                if prior:
                    previous_qty = float(prior['quantity_to_date'] or 0)

            # Backward compatible default: when no period quantities are given,
            # the remaining balance is treated as completed in this period.
            contract_qty = float(takeoff['quantity'] or 0)
            if current_quantities is None:
                period_qty = max(0.0, contract_qty - previous_qty)
            else:
                period_qty = float(current_quantities.get(int(takeoff['id']), current_quantities.get(str(takeoff['id']), 0)) or 0)
            if period_qty < 0:
                raise ValueError(f"مقدار جاری ردیف {takeoff['item_code']} نمی‌تواند منفی باشد.")
            cumulative_qty = previous_qty + period_qty

            result = calculate_statement_line(
                current_total_qty=cumulative_qty,
                previous_to_date_qty=previous_qty,
                unit_price=takeoff['unit_price'],
                waste_pct=takeoff['waste_pct'],
                transport_pct=takeoff['transport_pct'],
                other_direct_total=takeoff['other_direct'],
                coefficients=coefficient_rows,
                adjustment_factor=adjustment_factor,
                total_contract_qty=contract_qty,
            )
            total += result['final_amount']
            con.execute('''
                INSERT INTO statement_lines(
                    statement_id,takeoff_line_id,quantity_current,quantity_previous,quantity_to_date,
                    unit_price,amount_current,amount_previous,amount_to_date,adjustment_factor,
                    adjustment_amount,final_amount,note,
                    item_code_snapshot,description_snapshot,chapter_title_snapshot,unit_snapshot,
                    quantity_total_snapshot,waste_pct_snapshot,transport_pct_snapshot,other_direct_total_snapshot,
                    base_amount_current,waste_amount_current,transport_amount_current,other_direct_amount_current,
                    direct_amount_current,coefficient_amount_current,priced_amount_current,coefficient_snapshot_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ''', (
                statement_id, takeoff['id'], result['current_qty'], result['previous_qty'], result['to_date_qty'],
                result['unit_price'], result['priced_amount_current'], result['amount_previous'], result['amount_to_date'],
                adjustment_factor, result['adjustment_amount'], result['final_amount'], takeoff['note'] or '',
                takeoff['item_code'], takeoff['description'], takeoff['chapter_title'], takeoff['unit'],
                takeoff['quantity'], takeoff['waste_pct'], takeoff['transport_pct'], takeoff['other_direct'],
                result['base_amount_current'], result['waste_amount_current'], result['transport_amount_current'],
                result['other_direct_amount_current'], result['direct_amount_current'],
                result['coefficient_amount_current'], result['priced_amount_current'], coefficient_json,
            ))
    return statement_id, total


def statement_rows(con, statement_id):
    """Read archived rows even if the source takeoff item has been deleted."""
    return con.execute('''
        SELECT sl.*,
               COALESCE(NULLIF(sl.item_code_snapshot,''),t.item_code,'') AS item_code,
               COALESCE(NULLIF(sl.description_snapshot,''),t.description,'') AS description,
               COALESCE(NULLIF(sl.chapter_title_snapshot,''),t.chapter_title,'') AS chapter_title,
               COALESCE(NULLIF(sl.unit_snapshot,''),t.unit,'') AS unit
        FROM statement_lines sl
        LEFT JOIN takeoff_lines t ON t.id=sl.takeoff_line_id
        WHERE sl.statement_id=?
        ORDER BY sl.id
    ''', (int(statement_id),)).fetchall()


def statement_total(con, statement_id):
    row = con.execute(
        'SELECT COALESCE(SUM(final_amount),0) AS total FROM statement_lines WHERE statement_id=?',
        (int(statement_id),),
    ).fetchone()
    return float(row['total'] or 0)
