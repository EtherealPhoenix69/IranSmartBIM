from pathlib import Path
def build_estimate_xlsx(path,project_name,rows,total,coefficients=None,statement=None):
    import xlsxwriter
    Path(path).parent.mkdir(parents=True,exist_ok=True); wb=xlsxwriter.Workbook(str(path)); ws=wb.add_worksheet('گزارش')
    if hasattr(ws, 'right_to_left'): ws.right_to_left()
    title=wb.add_format({'bold':True,'font_size':16,'align':'center'}); hdr=wb.add_format({'bold':True,'font_color':'white','bg_color':'#17365D','border':1,'align':'center'}); num=wb.add_format({'num_format':'#,##0.000','border':1}); money=wb.add_format({'num_format':'#,##0','border':1}); tf=wb.add_format({'bold':True,'num_format':'#,##0','bg_color':'#D9E2F3','border':1})
    ws.merge_range('A1:M1',f'IranSmartBIM | {statement or "گزارش متره و برآورد"} | {project_name}',title); headers=['کد','شرح','فصل','واحد','مقدار','قیمت واحد','پایه','پرت','حمل','سایر مستقیم','ضرایب','تعدیل','نهایی']
    for c,h in enumerate(headers): ws.write(2,c,h,hdr)
    for r,l in enumerate(rows,3):
        vals=[l.get('item_code',''),l.get('description',''),l.get('chapter_title',''),l.get('unit',''),l.get('quantity',0),l.get('unit_price',0),l.get('base',0),l.get('waste',0),l.get('transport',0),l.get('other_direct',0),l.get('coefficient_amount',0),l.get('escalation',0),l.get('final',0)]
        for c,v in enumerate(vals): ws.write(r,c,v,num if c==4 else money if c>=5 else None)
    er=3+len(rows); ws.write(er,11,'جمع کل',hdr); ws.write(er,12,total,tf)
    for c,w in enumerate([14,40,24,10,14,16,18,16,16,18,18,18,20]): ws.set_column(c,c,w)
    ws.freeze_panes(3,0)
    if coefficients:
        cw=wb.add_worksheet('ضرایب');
        if hasattr(cw, 'right_to_left'): cw.right_to_left()
        cw.write_row(0,0,['نام','کد','نوع','مقدار','ترتیب'],hdr)
        for i,c in enumerate(coefficients,1): cw.write_row(i,0,[c.get('name'),c.get('code'),c.get('kind'),c.get('value'),c.get('sequence',10)])
    wb.close()
