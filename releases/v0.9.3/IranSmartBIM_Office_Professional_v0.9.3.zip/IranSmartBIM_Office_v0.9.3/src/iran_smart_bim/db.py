"""SQLite schema and forward-only, non-destructive migrations."""
from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA = r'''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS price_lists(
 id INTEGER PRIMARY KEY AUTOINCREMENT, year INTEGER NOT NULL, discipline TEXT NOT NULL,
 title TEXT NOT NULL, bulletin_no TEXT DEFAULT '', issue_date TEXT DEFAULT '', source TEXT DEFAULT '',
 UNIQUE(year,discipline)
);
CREATE TABLE IF NOT EXISTS projects(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, location TEXT DEFAULT '',
 contract_no TEXT DEFAULT '', base_year INTEGER, price_list_id INTEGER,
 employer TEXT DEFAULT '', consultant TEXT DEFAULT '', contractor TEXT DEFAULT '',
 contract_amount REAL DEFAULT 0, duration_days INTEGER DEFAULT 0,
 start_date TEXT DEFAULT '', end_date TEXT DEFAULT '', advance_amount REAL DEFAULT 0,
 retention_pct REAL DEFAULT 5, insurance_pct REAL DEFAULT 0, tax_pct REAL DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(price_list_id) REFERENCES price_lists(id)
);
CREATE TABLE IF NOT EXISTS chapters(
 id INTEGER PRIMARY KEY AUTOINCREMENT, price_list_id INTEGER NOT NULL, code TEXT NOT NULL, title TEXT NOT NULL,
 UNIQUE(price_list_id,code), FOREIGN KEY(price_list_id) REFERENCES price_lists(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS price_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT, chapter_id INTEGER NOT NULL, code TEXT NOT NULL,
 description TEXT NOT NULL, unit TEXT NOT NULL, unit_price REAL NOT NULL DEFAULT 0,
 labor_share REAL DEFAULT 0, material_share REAL DEFAULT 0, equipment_share REAL DEFAULT 0,
 source TEXT DEFAULT '', price_status TEXT NOT NULL DEFAULT 'available',
 UNIQUE(chapter_id,code,description), FOREIGN KEY(chapter_id) REFERENCES chapters(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS coefficients(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, code TEXT DEFAULT '',
 kind TEXT NOT NULL DEFAULT 'percent', value REAL NOT NULL DEFAULT 0,
 basis TEXT NOT NULL DEFAULT 'direct', applies_to TEXT DEFAULT 'all',
 enabled INTEGER DEFAULT 1, note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS project_coefficients(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, coefficient_id INTEGER NOT NULL,
 value REAL, sequence INTEGER DEFAULT 10, enabled INTEGER DEFAULT 1,
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
 FOREIGN KEY(coefficient_id) REFERENCES coefficients(id) ON DELETE CASCADE,
 UNIQUE(project_id,coefficient_id)
);
CREATE TABLE IF NOT EXISTS takeoff_lines(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, price_item_id INTEGER,
 item_code TEXT NOT NULL, description TEXT NOT NULL, chapter_code TEXT DEFAULT '', chapter_title TEXT DEFAULT '',
 unit TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0, unit_price REAL NOT NULL DEFAULT 0,
 waste_pct REAL DEFAULT 0, transport_pct REAL DEFAULT 0, other_direct REAL DEFAULT 0, note TEXT DEFAULT '',
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
 FOREIGN KEY(price_item_id) REFERENCES price_items(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS escalation_indices(
 id INTEGER PRIMARY KEY AUTOINCREMENT, year INTEGER NOT NULL, period TEXT NOT NULL,
 discipline TEXT NOT NULL, index_type TEXT NOT NULL, base_index REAL DEFAULT 0,
 current_index REAL DEFAULT 0, coefficient REAL DEFAULT 0, source TEXT DEFAULT '',
 UNIQUE(year,period,discipline,index_type)
);
CREATE TABLE IF NOT EXISTS statements(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, statement_no INTEGER NOT NULL,
 period TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'draft', description TEXT DEFAULT '',
 adjustment_factor REAL DEFAULT 0, coefficients_snapshot_json TEXT DEFAULT '[]',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(project_id,statement_no), FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS statement_lines(
 id INTEGER PRIMARY KEY AUTOINCREMENT, statement_id INTEGER NOT NULL, takeoff_line_id INTEGER,
 quantity_current REAL DEFAULT 0, quantity_previous REAL DEFAULT 0, quantity_to_date REAL DEFAULT 0,
 unit_price REAL DEFAULT 0, amount_current REAL DEFAULT 0, amount_previous REAL DEFAULT 0,
 amount_to_date REAL DEFAULT 0, adjustment_factor REAL DEFAULT 0, adjustment_amount REAL DEFAULT 0,
 final_amount REAL DEFAULT 0, note TEXT DEFAULT '',
 item_code_snapshot TEXT DEFAULT '', description_snapshot TEXT DEFAULT '',
 chapter_title_snapshot TEXT DEFAULT '', unit_snapshot TEXT DEFAULT '',
 quantity_total_snapshot REAL DEFAULT 0, waste_pct_snapshot REAL DEFAULT 0,
 transport_pct_snapshot REAL DEFAULT 0, other_direct_total_snapshot REAL DEFAULT 0,
 base_amount_current REAL DEFAULT 0, waste_amount_current REAL DEFAULT 0,
 transport_amount_current REAL DEFAULT 0, other_direct_amount_current REAL DEFAULT 0,
 direct_amount_current REAL DEFAULT 0, coefficient_amount_current REAL DEFAULT 0,
 priced_amount_current REAL DEFAULT 0, coefficient_snapshot_json TEXT DEFAULT '[]',
 FOREIGN KEY(statement_id) REFERENCES statements(id) ON DELETE CASCADE,
 FOREIGN KEY(takeoff_line_id) REFERENCES takeoff_lines(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS project_payments(
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
 payment_date TEXT NOT NULL, description TEXT DEFAULT '', amount REAL NOT NULL DEFAULT 0,
 reference_no TEXT DEFAULT '', FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_price_search ON price_items(code,description);
CREATE INDEX IF NOT EXISTS idx_takeoff_project ON takeoff_lines(project_id);
CREATE INDEX IF NOT EXISTS idx_statement_project ON statements(project_id,statement_no);
'''

SEED = [
    ('ضریب بالاسری', 'OVERHEAD', 'percent', 10, 'direct', 'all', 'نمونه قابل تنظیم طبق قرارداد'),
    ('ضریب تجهیز و برچیدن کارگاه', 'SITE', 'percent', 0, 'direct', 'all', 'نمونه قابل تنظیم طبق قرارداد'),
    ('ضریب منطقه', 'REGION', 'percent', 0, 'direct', 'all', 'نمونه قابل تنظیم طبق قرارداد'),
]

PROJECT_COLUMNS = {
    'employer': 'TEXT DEFAULT ""',
    'consultant': 'TEXT DEFAULT ""',
    'contractor': 'TEXT DEFAULT ""',
    'contract_amount': 'REAL DEFAULT 0',
    'duration_days': 'INTEGER DEFAULT 0',
    'start_date': 'TEXT DEFAULT ""',
    'end_date': 'TEXT DEFAULT ""',
    'advance_amount': 'REAL DEFAULT 0',
    'retention_pct': 'REAL DEFAULT 5',
    'insurance_pct': 'REAL DEFAULT 0',
    'tax_pct': 'REAL DEFAULT 0',
}

STATEMENT_COLUMNS = {
    'item_code_snapshot': 'TEXT DEFAULT ""',
    'description_snapshot': 'TEXT DEFAULT ""',
    'chapter_title_snapshot': 'TEXT DEFAULT ""',
    'unit_snapshot': 'TEXT DEFAULT ""',
    'quantity_total_snapshot': 'REAL DEFAULT 0',
    'waste_pct_snapshot': 'REAL DEFAULT 0',
    'transport_pct_snapshot': 'REAL DEFAULT 0',
    'other_direct_total_snapshot': 'REAL DEFAULT 0',
    'base_amount_current': 'REAL DEFAULT 0',
    'waste_amount_current': 'REAL DEFAULT 0',
    'transport_amount_current': 'REAL DEFAULT 0',
    'other_direct_amount_current': 'REAL DEFAULT 0',
    'direct_amount_current': 'REAL DEFAULT 0',
    'coefficient_amount_current': 'REAL DEFAULT 0',
    'priced_amount_current': 'REAL DEFAULT 0',
    'coefficient_snapshot_json': 'TEXT DEFAULT "[]"',
}


def _ensure_columns(con: sqlite3.Connection, table: str, columns: dict[str, str]) -> None:
    existing = {row[1] for row in con.execute(f'PRAGMA table_info({table})').fetchall()}
    for name, definition in columns.items():
        if name not in existing:
            con.execute(f'ALTER TABLE {table} ADD COLUMN {name} {definition}')


def _migrate_price_items(con: sqlite3.Connection) -> None:
    cols = {row[1] for row in con.execute('PRAGMA table_info(price_items)').fetchall()}
    if not cols or 'price_status' in cols:
        return
    # Historical versions stored the same core fields but did not track price status.
    con.execute("ALTER TABLE price_items ADD COLUMN price_status TEXT NOT NULL DEFAULT 'available'")


def _migrate_statement_snapshots(con: sqlite3.Connection) -> None:
    _ensure_columns(con, 'statement_lines', STATEMENT_COLUMNS)
    _ensure_columns(con, 'statements', {
        'adjustment_factor': 'REAL DEFAULT 0',
        'coefficients_snapshot_json': 'TEXT DEFAULT "[]"',
    })
    rows = con.execute('''
        SELECT sl.id, sl.takeoff_line_id, t.item_code, t.description, t.chapter_title,
               t.unit, t.quantity, t.waste_pct, t.transport_pct, t.other_direct
        FROM statement_lines sl
        LEFT JOIN takeoff_lines t ON t.id=sl.takeoff_line_id
        WHERE sl.item_code_snapshot='' OR sl.description_snapshot=''
    ''').fetchall()
    for row in rows:
        if row['takeoff_line_id'] is None:
            continue
        con.execute('''UPDATE statement_lines SET
            item_code_snapshot=COALESCE(NULLIF(item_code_snapshot,''),?),
            description_snapshot=COALESCE(NULLIF(description_snapshot,''),?),
            chapter_title_snapshot=COALESCE(NULLIF(chapter_title_snapshot,''),?),
            unit_snapshot=COALESCE(NULLIF(unit_snapshot,''),?),
            quantity_total_snapshot=CASE WHEN quantity_total_snapshot=0 THEN COALESCE(?,0) ELSE quantity_total_snapshot END,
            waste_pct_snapshot=CASE WHEN waste_pct_snapshot=0 THEN COALESCE(?,0) ELSE waste_pct_snapshot END,
            transport_pct_snapshot=CASE WHEN transport_pct_snapshot=0 THEN COALESCE(?,0) ELSE transport_pct_snapshot END,
            other_direct_total_snapshot=CASE WHEN other_direct_total_snapshot=0 THEN COALESCE(?,0) ELSE other_direct_total_snapshot END
            WHERE id=?''', (
                row['item_code'] or '', row['description'] or '', row['chapter_title'] or '', row['unit'] or '',
                row['quantity'], row['waste_pct'], row['transport_pct'], row['other_direct'], row['id'],
            ))



def _migrate_project_payments(con: sqlite3.Connection) -> None:
    """Normalize the payment date column used by older demo/database versions."""
    columns = {row[1] for row in con.execute('PRAGMA table_info(project_payments)').fetchall()}
    if 'payment_date' not in columns and 'pay_date' in columns:
        con.execute('ALTER TABLE project_payments RENAME COLUMN pay_date TO payment_date')
        columns.remove('pay_date')
        columns.add('payment_date')
    elif 'payment_date' in columns and 'pay_date' in columns:
        con.execute("UPDATE project_payments SET payment_date=COALESCE(NULLIF(payment_date,''),pay_date)")
    if 'payment_date' not in columns:
        con.execute("ALTER TABLE project_payments ADD COLUMN payment_date TEXT NOT NULL DEFAULT ''")
    con.execute('CREATE INDEX IF NOT EXISTS idx_project_payments ON project_payments(project_id,payment_date)')


def connect(path='data/iransmartbim.db'):
    db_path = Path(path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(db_path))
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=5000')
    con.executescript(SCHEMA)
    _migrate_price_items(con)
    _ensure_columns(con, 'projects', PROJECT_COLUMNS)
    _migrate_project_payments(con)
    _migrate_statement_snapshots(con)
    for row in SEED:
        if not con.execute('SELECT 1 FROM coefficients WHERE code=?', (row[1],)).fetchone():
            con.execute('''INSERT INTO coefficients(name,code,kind,value,basis,applies_to,note)
                           VALUES(?,?,?,?,?,?,?)''', row)
    con.commit()
    return con
