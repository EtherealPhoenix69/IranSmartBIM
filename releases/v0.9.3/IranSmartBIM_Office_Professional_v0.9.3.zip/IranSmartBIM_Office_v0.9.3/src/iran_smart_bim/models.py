from dataclasses import dataclass

@dataclass
class CostBreakdown:
    base: float
    waste: float
    transport: float
    other_direct: float
    direct: float
    coefficient_amount: float
    priced: float
    escalation: float
    final: float

@dataclass
class StatementLineResult:
    current_qty: float
    previous_qty: float
    to_date_qty: float
    current_amount: float
    previous_amount: float
    to_date_amount: float
    adjustment_amount: float
    final_amount: float
