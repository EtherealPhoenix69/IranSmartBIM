"""Shared calculation engine for estimates and interim statements.

`other_direct` is defined as an absolute amount for the complete takeoff line.
For interim statements it is prorated by current/to-date quantity so that a
100% completed statement reconciles with the original estimate.
"""
from __future__ import annotations

import math
from typing import Iterable, Mapping

from .models import CostBreakdown, StatementLineResult


def _number(value, name: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be numeric") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def calculate_line(
    quantity,
    unit_price,
    waste_pct=0,
    transport_pct=0,
    other_direct=0,
    coefficients: Iterable[Mapping] | None = None,
    escalation_factor=0,
) -> CostBreakdown:
    """Calculate one complete takeoff line.

    Percentages are entered as percentage points (10 means 10%).
    `escalation_factor` is a multiplier fraction (0.10 means 10%).
    `other_direct` is a total line amount, not a per-unit amount.
    """
    q = _number(quantity, "quantity")
    price = _number(unit_price, "unit_price")
    waste_rate = _number(waste_pct, "waste_pct")
    transport_rate = _number(transport_pct, "transport_pct")
    other = _number(other_direct, "other_direct")
    adjustment = _number(escalation_factor, "escalation_factor")

    if q < 0:
        raise ValueError("quantity cannot be negative")
    if price < 0:
        raise ValueError("unit_price cannot be negative")
    if not 0 <= waste_rate <= 100:
        raise ValueError("waste_pct must be between 0 and 100")
    if not 0 <= transport_rate <= 100:
        raise ValueError("transport_pct must be between 0 and 100")

    base = q * price
    waste = base * waste_rate / 100.0
    transport = base * transport_rate / 100.0
    direct = base + waste + transport + other

    running = direct
    coefficient_amount = 0.0
    for coefficient in sorted(coefficients or [], key=lambda item: int(item.get("sequence") or 10)):
        if not coefficient.get("enabled", True):
            continue
        basis = coefficient.get("basis", "direct")
        if basis not in ("direct", "all"):
            continue
        value = _number(coefficient.get("value", 0), "coefficient value")
        before = running
        kind = coefficient.get("kind", "percent")
        if kind == "percent":
            running = before + before * value / 100.0
        elif kind in ("factor", "multiplier"):
            if value < 0:
                raise ValueError("coefficient factor cannot be negative")
            running = before * value
        else:
            raise ValueError(f"unsupported coefficient kind: {kind}")
        coefficient_amount += running - before

    priced = running
    escalation = priced * adjustment
    return CostBreakdown(
        base=base,
        waste=waste,
        transport=transport,
        other_direct=other,
        direct=direct,
        coefficient_amount=coefficient_amount,
        priced=priced,
        escalation=escalation,
        final=priced + escalation,
    )


def statement_line(current_total_qty, previous_to_date_qty, unit_price, adjustment_factor=0):
    """Legacy base-only line helper, retained for downstream compatibility."""
    total_qty = _number(current_total_qty, "current_total_qty")
    previous_qty = _number(previous_to_date_qty, "previous_to_date_qty")
    price = _number(unit_price, "unit_price")
    factor = _number(adjustment_factor, "adjustment_factor")
    if total_qty < 0 or previous_qty < 0 or price < 0:
        raise ValueError("quantities and unit_price cannot be negative")
    if total_qty + 1e-9 < previous_qty:
        raise ValueError("cumulative quantity cannot be less than previous quantity")
    current = max(0.0, total_qty - previous_qty)
    previous = previous_qty
    to_date = total_qty
    current_amount = current * price
    previous_amount = previous * price
    to_date_amount = to_date * price
    adjustment_amount = current_amount * factor
    return StatementLineResult(
        current, previous, to_date, current_amount, previous_amount,
        to_date_amount, adjustment_amount, current_amount + adjustment_amount,
    )


def calculate_statement_line(
    current_total_qty,
    previous_to_date_qty,
    unit_price,
    waste_pct=0,
    transport_pct=0,
    other_direct_total=0,
    coefficients=None,
    adjustment_factor=0,
    total_contract_qty=None,
):
    """Calculate a statement period using the same formula as the estimate.

    `current_total_qty` is cumulative executed quantity to date. The fixed
    `other_direct_total` is allocated against the complete takeoff quantity,
    not the current progress quantity, so split periods reconcile at 100%.
    """
    total_qty = _number(current_total_qty, "current_total_qty")
    previous_qty = _number(previous_to_date_qty, "previous_to_date_qty")
    contract_qty = total_qty if total_contract_qty is None else _number(total_contract_qty, "total_contract_qty")
    if total_qty < 0 or previous_qty < 0 or contract_qty < 0:
        raise ValueError("quantities cannot be negative")
    if total_qty + 1e-9 < previous_qty:
        raise ValueError(
            "cumulative quantity is lower than the previous statement; "
            "use a separate correction/negative line instead of reducing history"
        )
    if total_qty > contract_qty + 1e-9:
        raise ValueError("cumulative executed quantity exceeds the takeoff quantity")

    current_qty = max(0.0, total_qty - previous_qty)
    other_total = _number(other_direct_total, "other_direct_total")

    def allocated_other(qty):
        if contract_qty <= 0:
            return 0.0
        return other_total * qty / contract_qty

    previous_breakdown = calculate_line(
        previous_qty, unit_price, waste_pct, transport_pct,
        allocated_other(previous_qty), coefficients,
    )
    current_breakdown = calculate_line(
        current_qty, unit_price, waste_pct, transport_pct,
        allocated_other(current_qty), coefficients,
        escalation_factor=adjustment_factor,
    )
    to_date_breakdown = calculate_line(
        total_qty, unit_price, waste_pct, transport_pct,
        allocated_other(total_qty), coefficients,
    )

    return {
        "current_qty": current_qty,
        "previous_qty": previous_qty,
        "to_date_qty": total_qty,
        "unit_price": _number(unit_price, "unit_price"),
        "base_amount_current": current_breakdown.base,
        "waste_amount_current": current_breakdown.waste,
        "transport_amount_current": current_breakdown.transport,
        "other_direct_amount_current": current_breakdown.other_direct,
        "direct_amount_current": current_breakdown.direct,
        "coefficient_amount_current": current_breakdown.coefficient_amount,
        "priced_amount_current": current_breakdown.priced,
        "amount_previous": previous_breakdown.priced,
        "amount_to_date": to_date_breakdown.priced,
        "adjustment_factor": _number(adjustment_factor, "adjustment_factor"),
        "adjustment_amount": current_breakdown.escalation,
        "final_amount": current_breakdown.final,
    }
