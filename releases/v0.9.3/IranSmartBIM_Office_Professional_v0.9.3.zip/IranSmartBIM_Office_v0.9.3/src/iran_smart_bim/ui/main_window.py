import os, sys, shutil
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QSize
from PySide6.QtGui import QFont, QIcon, QAction
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QStackedWidget, QFrame, QMessageBox, QFileDialog, QGroupBox,
    QFormLayout, QDialog, QDialogButtonBox, QPlainTextEdit, QSizePolicy, QTabWidget, QProgressBar
)
from ..db import connect
from ..calculation import calculate_line
from ..services.pricebook import search_items, price_lists, chapters, get_item, update_analysis
from ..services.importers import import_price_csv
from ..services.statements import create_statement, statement_rows
from ..services.excel_report import build_estimate_xlsx
from ..services.reporting import pdf_report

APP_NAME = "IranSmartBIM"
APP_VERSION = "0.9.3"
ROOT = Path(__file__).resolve().parents[3]
IS_FROZEN = bool(getattr(sys, "frozen", False))
if IS_FROZEN:
    DATA_ROOT = Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "IranSmartBIM"
    BUNDLE_ROOT = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
else:
    DATA_ROOT = ROOT / "data"
    BUNDLE_ROOT = ROOT
DATA_ROOT.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_ROOT / "iransmartbim.db"
BUNDLED_PRICEBOOK = BUNDLE_ROOT / "data" / "price_items_abniyeh_1404.csv"

QSS = r'''
QMainWindow, QWidget { background:#f4f7fb; color:#19324d; font-family:"Segoe UI"; }
#Sidebar { background:#0b1f33; border:0; }
#Brand { color:white; font-size:19px; font-weight:700; padding:12px 8px 2px; }
#BrandSub { color:#9fc3df; font-size:10px; padding:0 8px 15px; }
.NavButton { text-align:right; color:#dce9f6; background:transparent; border:0; padding:12px 14px; border-radius:10px; font-size:13px; }
.NavButton:hover { background:#163754; }
.NavButton[active="true"] { background:#0f7ee6; color:white; font-weight:700; }
#TopBar { background:white; border-bottom:1px solid #dbe5ef; }
#PageTitle { font-size:22px; font-weight:700; color:#17324f; }
#PageSub { color:#6b8194; font-size:11px; }
.Card { background:white; border:1px solid #e0e8f0; border-radius:14px; }
.CardTitle { font-size:13px; font-weight:700; color:#17324f; }
.Metric { font-size:22px; font-weight:800; color:#0d5fa8; }
.MetricCaption { color:#6f8292; font-size:10px; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit { background:white; border:1px solid #cdd9e5; border-radius:8px; padding:7px 9px; min-height:18px; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus { border:1px solid #0f7ee6; }
QPushButton[class="Primary"] { background:#0f7ee6; color:white; border:0; border-radius:8px; padding:8px 14px; font-weight:700; }
QPushButton[class="Primary"]:hover { background:#0b6bc4; }
QPushButton[class="Secondary"] { background:#eef5fb; color:#195b8f; border:1px solid #cfe0ef; border-radius:8px; padding:8px 14px; }
QTableWidget { background:white; border:1px solid #dce6ef; border-radius:10px; gridline-color:#e8eef4; }
QHeaderView::section { background:#f1f6fa; color:#4f687c; padding:8px; border:0; font-weight:700; }
QTableWidget::item:selected { background:#dceeff; color:#17324f; }
QStatusBar { background:#102a42; color:#d7e9f7; }
''' 

class Card(QFrame):
    def __init__(self):
        super().__init__(); self.setObjectName("Card"); self.setProperty("class", "Card")
        self.setStyleSheet("QFrame#Card { background:white; border:1px solid #e0e8f0; border-radius:14px; }")

class PriceCompareDialog(QDialog):
    def __init__(self, parent, rows):
        super().__init__(parent); self.setWindowTitle("مقایسه ردیف‌ها"); self.resize(1000, 480)
        lay=QVBoxLayout(self); table=QTableWidget(0,8); table.setHorizontalHeaderLabels(["کد","شرح","فصل","واحد","قیمت واحد","مصالح","دستمزد","ماشین‌آلات"])
        table.setSelectionBehavior(QAbstractItemView.SelectRows); table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for r in rows:
            i=table.rowCount(); table.insertRow(i)
            vals=[r['code'],r['description'],f"{r['chapter_code']} - {r['chapter_title']}",r['unit'],f"{r['unit_price']:,.0f}",f"{float(r['material_share'] or 0):.1f}%",f"{float(r['labor_share'] or 0):.1f}%",f"{float(r['equipment_share'] or 0):.1f}%"]
            for c,v in enumerate(vals): table.setItem(i,c,QTableWidgetItem(str(v)))
        table.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); lay.addWidget(table)
        b=QPushButton("بستن"); b.clicked.connect(self.accept); lay.addWidget(b,0,Qt.AlignLeft)

class AnalysisDialog(QDialog):
    def __init__(self,parent,row):
        super().__init__(parent); self.row=row; self.setWindowTitle("آنالیز بها"); self.resize(520, 340)
        root=QVBoxLayout(self); form=QFormLayout();
        self.material=self.spin(row['material_share']); self.labor=self.spin(row['labor_share']); self.equipment=self.spin(row['equipment_share']); self.other=QLabel(); self.total=QLabel()
        form.addRow("مصالح",self.material); form.addRow("دستمزد",self.labor); form.addRow("ماشین‌آلات",self.equipment); form.addRow("سایر",self.other); form.addRow("جمع",self.total); root.addLayout(form)
        for x in [self.material,self.labor,self.equipment]: x.valueChanged.connect(self.refresh)
        btn=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); btn.accepted.connect(self.accept); btn.rejected.connect(self.reject); root.addWidget(btn); self.refresh()
    def spin(self,v):
        s=QDoubleSpinBox(); s.setRange(0,100); s.setDecimals(2); s.setValue(float(v or 0)); s.setSuffix(" %"); return s
    def refresh(self):
        t=self.material.value()+self.labor.value()+self.equipment.value(); self.other.setText(f"{max(0,100-t):.2f} %"); self.total.setText(f"{t:.2f} %")
    def values(self): return self.material.value(),self.labor.value(),self.equipment.value()


class StatementQuantityDialog(QDialog):
    """Collect this-period executed quantities without changing takeoff totals."""
    def __init__(self, parent, takeoff_rows, previous_quantities):
        super().__init__(parent)
        self.setWindowTitle("ورود مقادیر اجرای این دوره")
        self.resize(1050, 620)
        self._spins = {}
        root = QVBoxLayout(self)
        hint = QLabel("مقدار کل متره ثابت است. فقط مقدار اجراشده در همین دوره را وارد کنید؛ مقدار قبلی و تا تاریخ خودکار محاسبه می‌شوند.")
        hint.setWordWrap(True)
        root.addWidget(hint)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["کد", "شرح", "واحد", "مقدار کل متره", "قبلی تا تاریخ", "مقدار جاری این دوره"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        for row in takeoff_rows:
            line_id = int(row['id'])
            total = float(row['quantity'] or 0)
            previous = float(previous_quantities.get(line_id, 0.0))
            remaining = max(0.0, total - previous)
            i = self.table.rowCount(); self.table.insertRow(i)
            values = [row['item_code'], row['description'], row['unit'], f"{total:,.4f}", f"{previous:,.4f}"]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value)); item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                if col == 0: item.setData(Qt.UserRole, line_id)
                self.table.setItem(i, col, item)
            spin = QDoubleSpinBox(); spin.setRange(0, remaining); spin.setDecimals(4); spin.setMaximumWidth(150)
            spin.setValue(0); spin.setToolTip(f"حداکثر مقدار مجاز این دوره: {remaining:,.4f}")
            self.table.setCellWidget(i, 5, spin); self._spins[line_id] = spin
        root.addWidget(self.table, 1)
        footer = QHBoxLayout()
        fill = QPushButton("تکمیل مانده همه ردیف‌ها")
        fill.clicked.connect(self.fill_remaining)
        footer.addWidget(fill); footer.addStretch()
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("ادامه و صدور")
        buttons.button(QDialogButtonBox.Cancel).setText("انصراف")
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        footer.addWidget(buttons); root.addLayout(footer)

    def fill_remaining(self):
        for spin in self._spins.values(): spin.setValue(spin.maximum())

    def current_quantities(self):
        return {line_id: spin.value() for line_id, spin in self._spins.items()}


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle(f"{APP_NAME} | دفتر فنی"); self.resize(1500, 920); self.setMinimumSize(1180,760)
        self.con=connect(str(DB_PATH)); self.project_id=None; self.selected_item_id=None
        self.search_timer=QTimer(self); self.search_timer.setSingleShot(True); self.search_timer.setInterval(180); self.search_timer.timeout.connect(self.refresh_pricebook)
        self.nav_buttons=[]; self.current_price_rows=[]; self.build_ui(); self.ensure_seed_pricebook(); self.load_pricebook_meta(); self.apply_project_summary(); self.refresh_pricebook(); self.refresh_takeoff(); self.refresh_statements()
    def build_ui(self):
        root=QWidget(); self.setCentralWidget(root); outer=QHBoxLayout(root); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        self.sidebar=QFrame(); self.sidebar.setObjectName("Sidebar"); self.sidebar.setFixedWidth(230); sb=QVBoxLayout(self.sidebar); sb.setContentsMargins(14,18,14,14)
        brand=QLabel("IranSmartBIM"); brand.setObjectName("Brand"); sb.addWidget(brand)
        sub=QLabel("Plan · Measure · Estimate · Build"); sub.setObjectName("BrandSub"); sb.addWidget(sub)
        for key,text,icon in [("dashboard","داشبورد","⌂"),("projects","پروژه و متره","▦"),("pricebook","فهرست‌بها","▤"),("analysis","آنالیز بها","◔"),("coeff","ضرایب پیمان","◫"),("statement","صورت‌وضعیت","▤"),("finance","وضعیت مالی","₿"),("reports","گزارش‌ها","□"),("settings","تنظیمات","⚙")]:
            b=QPushButton(f"{icon}   {text}"); b.setProperty("class","NavButton"); b.setProperty("active",False); b.setCursor(Qt.PointingHandCursor); b.clicked.connect(lambda checked=False,k=key:self.goto(k)); sb.addWidget(b); self.nav_buttons.append((key,b))
        sb.addStretch(); v=QLabel(f"نسخه {APP_VERSION}"); v.setStyleSheet("color:#7ca6c4;font-size:10px;padding:4px 8px;"); sb.addWidget(v)
        outer.addWidget(self.sidebar)
        content=QWidget(); cv=QVBoxLayout(content); cv.setContentsMargins(0,0,0,0); cv.setSpacing(0)
        top=QFrame(); top.setObjectName("TopBar"); tl=QHBoxLayout(top); tl.setContentsMargins(18,12,18,12)
        left=QVBoxLayout(); self.page_title=QLabel("داشبورد"); self.page_title.setObjectName("PageTitle"); self.page_sub=QLabel("کنترل سریع پروژه، متره و هزینه"); self.page_sub.setObjectName("PageSub"); left.addWidget(self.page_title); left.addWidget(self.page_sub); tl.addLayout(left); tl.addStretch()
        self.project_combo=QComboBox(); self.project_combo.setMinimumWidth(280); self.project_combo.currentIndexChanged.connect(self.project_changed); tl.addWidget(QLabel("پروژه فعال:")); tl.addWidget(self.project_combo)
        cv.addWidget(top)
        self.stack=QStackedWidget(); cv.addWidget(self.stack); outer.addWidget(content,1)
        self.pages={k:self.make_page(k) for k in ["dashboard","projects","pricebook","analysis","coeff","statement","finance","reports","settings"]}
        self.goto("dashboard")
    def make_page(self,key):
        w=QWidget(); lay=QVBoxLayout(w); lay.setContentsMargins(22,20,22,18); lay.setSpacing(14)
        if key=="dashboard": self.build_dashboard(lay)
        elif key=="projects": self.build_projects(lay)
        elif key=="pricebook": self.build_pricebook(lay)
        elif key=="analysis": self.build_analysis(lay)
        elif key=="coeff": self.build_coeff(lay)
        elif key=="statement": self.build_statement(lay)
        elif key=="finance": self.build_finance(lay)
        elif key=="reports": self.build_reports(lay)
        elif key=="settings": self.build_settings(lay)
        self.stack.addWidget(w); return w
    def section_header(self,layout,title,sub):
        h=QHBoxLayout(); t=QVBoxLayout(); a=QLabel(title); a.setObjectName("PageTitle"); b=QLabel(sub); b.setObjectName("PageSub"); t.addWidget(a); t.addWidget(b); h.addLayout(t); h.addStretch(); layout.addLayout(h)
    def metric(self,title,value="0"):
        c=Card(); l=QVBoxLayout(c); lab=QLabel(title); lab.setObjectName("MetricCaption"); val=QLabel(value); val.setObjectName("Metric"); l.addWidget(lab); l.addWidget(val); return c,val
    def build_dashboard(self,lay):
        self.section_header(lay,"داشبورد مدیریتی","وضعیت لحظه‌ای پروژه فعال، قرارداد، برآورد و پرداخت‌ها")
        grid=QGridLayout()
        items=[("مبلغ پیمان","0 ریال"),("برآورد فعلی","0 ریال"),("پرداخت‌شده","0 ریال"),("مانده پیمان","0 ریال"),("پیشرفت مالی","0%"),("ردیف‌های متره","0"),("صورت‌وضعیت‌ها","0"),("آخرین صورت‌وضعیت","0 ریال")]
        self.metrics=[]
        cards=[]
        for idx,(title,value) in enumerate(items):
            c,v=self.metric(title,value); self.metrics.append(v); cards.append(c); grid.addWidget(c,idx//4,idx%4)
        lay.addLayout(grid)
        lower=QHBoxLayout()
        card=Card(); cl=QVBoxLayout(card); ttl=QLabel("پیشرفت مالی نسبت به مبلغ مبنای پروژه"); ttl.setObjectName("CardTitle"); cl.addWidget(ttl)
        self.progress_fin=QProgressBar(); self.progress_fin.setRange(0,100); self.progress_fin.setTextVisible(True); self.progress_fin.setMinimumHeight(24); cl.addWidget(self.progress_fin)
        self.dashboard_hint=QLabel("پروژه‌ای انتخاب نشده است."); self.dashboard_hint.setObjectName("PageSub"); cl.addWidget(self.dashboard_hint); lower.addWidget(card,2)
        quick=Card(); ql=QVBoxLayout(quick); ql.addWidget(QLabel("دسترسی سریع",objectName="CardTitle"))
        for txt,key in [("➕ ایجاد / ویرایش پروژه","projects"),("▤ جستجوی فهرست‌بها","pricebook"),("◔ آنالیز بها","analysis"),("▤ صدور صورت‌وضعیت","statement"),("₿ ثبت پرداخت","finance")]:
            b=QPushButton(txt); b.setProperty("class","Primary" if key in ("projects","statement") else "Secondary"); b.clicked.connect(lambda _,k=key:self.goto(k)); ql.addWidget(b)
        lower.addWidget(quick,1); lay.addLayout(lower); lay.addStretch()
    def build_projects(self,lay):
        self.section_header(lay,"پروژه و متره","مدیریت مشخصات پروژه، اطلاعات قرارداد و ردیف‌های متره")
        tabs=QTabWidget()
        contract_tab=QWidget(); f=QFormLayout(contract_tab)
        self.pname=QLineEdit(); self.loc=QLineEdit(); self.contract=QLineEdit(); self.baseyear=QSpinBox(); self.baseyear.setRange(1390,1500); self.baseyear.setValue(1404)
        self.employer=QLineEdit(); self.consultant=QLineEdit(); self.contractor=QLineEdit()
        self.contract_amount=QDoubleSpinBox(); self.contract_amount.setRange(0,1e15); self.contract_amount.setDecimals(0); self.contract_amount.setGroupSeparatorShown(True)
        self.duration=QSpinBox(); self.duration.setRange(0,10000); self.start_date=QLineEdit(); self.end_date=QLineEdit()
        self.advance=QDoubleSpinBox(); self.advance.setRange(0,1e15); self.advance.setDecimals(0); self.advance.setGroupSeparatorShown(True)
        self.retention=QDoubleSpinBox(); self.retention.setRange(0,100); self.retention.setValue(5); self.retention.setSuffix(" %")
        self.insurance=QDoubleSpinBox(); self.insurance.setRange(0,100); self.insurance.setSuffix(" %")
        self.tax=QDoubleSpinBox(); self.tax.setRange(0,100); self.tax.setSuffix(" %")
        fields=[("نام پروژه",self.pname),("محل پروژه",self.loc),("شماره قرارداد",self.contract),("سال پایه",self.baseyear),
                ("کارفرما",self.employer),("مشاور",self.consultant),("پیمانکار",self.contractor),
                ("مبلغ اولیه پیمان (ریال)",self.contract_amount),("مدت پیمان (روز)",self.duration),
                ("تاریخ شروع (شمسی)",self.start_date),("تاریخ پایان (شمسی)",self.end_date),
                ("پیش‌پرداخت (ریال)",self.advance),("سپرده حسن انجام کار",self.retention),
                ("بیمه قراردادی",self.insurance),("مالیات قراردادی",self.tax)]
        for lab,x in fields: f.addRow(lab,x)
        buttons=QHBoxLayout(); save=QPushButton("ذخیره پروژه و قرارداد"); save.setProperty("class","Primary"); save.clicked.connect(self.save_project)
        new=QPushButton("پروژه جدید"); new.setProperty("class","Secondary"); new.clicked.connect(self.new_project)
        buttons.addWidget(save); buttons.addWidget(new); buttons.addStretch(); f.addRow(buttons)
        tabs.addTab(contract_tab,"اطلاعات پروژه و قرارداد")

        take_tab=QWidget(); tl=QVBoxLayout(take_tab)
        card2=Card(); r=QHBoxLayout(card2); r.addWidget(QLabel("ردیف فهرست‌بها")); self.selcode=QLineEdit(); self.selcode.setReadOnly(True); self.selcode.setPlaceholderText("از تب فهرست‌بها انتخاب کنید")
        self.qty=QDoubleSpinBox(); self.qty.setRange(0,1e12); self.qty.setDecimals(4); self.qty.setValue(1)
        self.waste=QDoubleSpinBox(); self.waste.setRange(0,100); self.waste.setDecimals(3); self.waste.setSuffix(" %")
        self.transport=QDoubleSpinBox(); self.transport.setRange(0,100); self.transport.setDecimals(3); self.transport.setSuffix(" %")
        add=QPushButton("افزودن به متره"); add.setProperty("class","Primary"); add.clicked.connect(self.add_takeoff)
        for x in [self.selcode,QLabel("مقدار"),self.qty,QLabel("پرت"),self.waste,QLabel("حمل"),self.transport,add]: r.addWidget(x)
        tl.addWidget(card2)
        self.tkt=QTableWidget(0,11); self.tkt.setHorizontalHeaderLabels(["شناسه","کد","شرح","فصل","واحد","مقدار","قیمت واحد","مبلغ پایه","ضرایب","تعدیل","نهایی"])
        self.tkt.setSelectionBehavior(QAbstractItemView.SelectRows); self.tkt.setSelectionMode(QAbstractItemView.SingleSelection); self.tkt.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tkt.horizontalHeader().setSectionResizeMode(2,QHeaderView.Stretch); self.tkt.cellDoubleClicked.connect(lambda _r,_c:self.edit_takeoff()); tl.addWidget(self.tkt,1)
        br=QHBoxLayout(); edit=QPushButton("ویرایش ردیف"); edit.clicked.connect(self.edit_takeoff); rm=QPushButton("حذف ردیف"); rm.clicked.connect(self.remove_takeoff); ex=QPushButton("خروجی Excel"); ex.clicked.connect(self.export_excel); pdf=QPushButton("خروجی PDF"); pdf.clicked.connect(self.export_pdf)
        for b in [edit,rm,ex,pdf]: b.setProperty("class","Secondary"); br.addWidget(b)
        br.addStretch(); self.project_total=QLabel("جمع: 0 ریال"); br.addWidget(self.project_total); tl.addLayout(br)
        tabs.addTab(take_tab,"متره و برآورد")
        lay.addWidget(tabs,1)
    def build_pricebook(self,lay):
        self.section_header(lay,"فهرست‌بها","جستجوی لحظه‌ای، فیلتر فصل، انتخاب و افزودن مستقیم به متره")
        filters=Card(); fl=QGridLayout(filters); self.plyear=QComboBox(); self.pldisc=QComboBox(); self.chfilter=QComboBox(); self.psearch=QLineEdit(); self.psearch.setPlaceholderText("جستجوی کد یا شرح... (لحظه‌ای)"); self.psearch.textChanged.connect(lambda _:self.queue_price_search());
        for lab,x in [("سال",self.plyear),("رشته",self.pldisc),("فصل",self.chfilter),("جستجو",self.psearch)]: pass
        fl.addWidget(QLabel("سال"),0,0); fl.addWidget(self.plyear,0,1); fl.addWidget(QLabel("رشته"),0,2); fl.addWidget(self.pldisc,0,3); fl.addWidget(QLabel("فصل"),0,4); fl.addWidget(self.chfilter,0,5); fl.addWidget(QLabel("جستجو"),1,0); fl.addWidget(self.psearch,1,1,1,5); lay.addWidget(filters)
        body=QHBoxLayout(); self.ptable=QTableWidget(0,6); self.ptable.setHorizontalHeaderLabels(["کد","شرح","فصل","واحد","قیمت واحد","وضعیت"]); self.ptable.setSelectionMode(QAbstractItemView.ExtendedSelection); self.ptable.setSelectionBehavior(QAbstractItemView.SelectRows); self.ptable.itemSelectionChanged.connect(self.show_price_details); self.ptable.cellDoubleClicked.connect(lambda r,c:self.select_price()); self.ptable.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); body.addWidget(self.ptable,3)
        detail=Card(); dl=QVBoxLayout(detail); h=QHBoxLayout(); self.det_code=QLabel("-"); self.det_code.setStyleSheet("font-size:18px;font-weight:800;"); h.addWidget(self.det_code); h.addStretch(); self.det_add=QPushButton("افزودن به متره"); self.det_add.setProperty("class","Primary"); self.det_add.clicked.connect(self.select_price); h.addWidget(self.det_add); dl.addLayout(h); self.det_ch=QLabel("-"); self.det_unit=QLabel("-"); self.det_price=QLabel("-"); self.det_source=QLabel("-"); self.det_desc=QPlainTextEdit(); self.det_desc.setReadOnly(True); self.det_desc.setMinimumHeight(130); self.det_analysis=QLabel("آنالیز بها: -"); dl.addWidget(self.det_ch); dl.addWidget(self.det_unit); dl.addWidget(self.det_price); dl.addWidget(self.det_source); dl.addWidget(self.det_desc); dl.addWidget(self.det_analysis); body.addWidget(detail,2); lay.addLayout(body,1)
        actions=QHBoxLayout(); cmp=QPushButton("مقایسه ردیف‌های انتخاب‌شده"); cmp.setProperty("class","Secondary"); cmp.clicked.connect(self.compare_prices); an=QPushButton("ویرایش آنالیز بها"); an.setProperty("class","Secondary"); an.clicked.connect(self.edit_analysis); multi=QPushButton("افزودن انتخاب‌شده‌ها به متره"); multi.setProperty("class","Primary"); multi.clicked.connect(self.add_selected_prices_to_takeoff); imp=QPushButton("Import CSV"); imp.setProperty("class","Secondary"); imp.clicked.connect(self.import_price); actions.addWidget(cmp); actions.addWidget(an); actions.addWidget(multi); actions.addStretch(); actions.addWidget(imp); lay.addLayout(actions)
    def build_analysis(self,lay):
        self.section_header(lay,"آنالیز بها","ترکیب مصالح، دستمزد، ماشین‌آلات و سایر")
        c=Card(); l=QVBoxLayout(c); self.analysis_summary=QLabel("یک ردیف را در فهرست‌بها انتخاب کنید."); l.addWidget(self.analysis_summary); lay.addWidget(c); lay.addStretch()
    def build_coeff(self,lay):
        self.section_header(lay,"ضرایب پیمان","تعریف و تخصیص ضرایب به پروژه فعال")
        c=Card(); f=QGridLayout(c); self.cname=QLineEdit(); self.ccode=QLineEdit(); self.ckind=QComboBox(); self.ckind.addItems(["percent","factor"]); self.cvalue=QDoubleSpinBox(); self.cvalue.setRange(-1000,1000); self.cvalue.setDecimals(3); self.cbasis=QComboBox(); self.cbasis.addItems(["direct","all"]); self.cseq=QSpinBox(); self.cseq.setRange(1,999); self.cseq.setValue(10); b=QPushButton("افزودن ضریب"); b.setProperty("class","Primary"); b.clicked.connect(self.add_coefficient)
        for i,(lab,x) in enumerate([("نام",self.cname),("کد",self.ccode),("نوع",self.ckind),("مقدار",self.cvalue),("مبنا",self.cbasis),("ترتیب",self.cseq)]): f.addWidget(QLabel(lab),0,i*2); f.addWidget(x,1,i*2)
        f.addWidget(b,1,12); lay.addWidget(c); self.ct=QTableWidget(0,6); self.ct.setHorizontalHeaderLabels(["شناسه","نام","کد","نوع","مقدار","ترتیب"]); self.ct.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); lay.addWidget(self.ct,1)
    def build_statement(self,lay):
        self.section_header(lay,"صورت‌وضعیت","صدور دوره‌ای بر مبنای همان موتور محاسبات برآورد و نگهداری آرشیو")
        c=Card(); f=QHBoxLayout(c); self.sno=QSpinBox(); self.sno.setRange(1,9999); self.sno.setValue(1); self.period=QLineEdit("دوره جاری")
        self.adj=QDoubleSpinBox(); self.adj.setDecimals(3); self.adj.setRange(-100,1000); self.adj.setSingleStep(0.1); self.adj.setSuffix(' %')
        gen=QPushButton("صدور صورت‌وضعیت"); gen.setProperty("class","Primary"); gen.clicked.connect(self.make_statement)
        for w in [QLabel("شماره"),self.sno,QLabel("دوره"),self.period,QLabel("نرخ تعدیل"),self.adj,gen]: f.addWidget(w)
        lay.addWidget(c)
        self.st=QTableWidget(0,9); self.st.setHorizontalHeaderLabels(["کد","شرح","جاری","قبلی","تا تاریخ","قیمت واحد","مبلغ جاری با ضرایب","تعدیل","نهایی"]); self.st.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); lay.addWidget(self.st,1)
        self.sttotal=QLabel("جمع صورت‌وضعیت: 0 ریال"); lay.addWidget(self.sttotal)
        self.statement_archive=QTableWidget(0,4); self.statement_archive.setMaximumHeight(180); self.statement_archive.setHorizontalHeaderLabels(["شماره","دوره","مبلغ نهایی (ریال)","تاریخ ثبت"]); self.statement_archive.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); self.statement_archive.setSelectionBehavior(QAbstractItemView.SelectRows); self.statement_archive.itemSelectionChanged.connect(self.show_archived_statement); lay.addWidget(QLabel("آرشیو صورت‌وضعیت‌های پروژه")); lay.addWidget(self.statement_archive)
    def build_finance(self,lay):
        self.section_header(lay,"وضعیت مالی پروژه","ثبت دریافت‌ها و پرداخت‌های ثبت‌شده؛ تفکیک‌شده بر اساس پروژه فعال")
        c=Card(); f=QFormLayout(c)
        self.pay_date=QLineEdit("1405/01/01"); self.pay_desc=QLineEdit(); self.pay_ref=QLineEdit()
        self.pay_amount=QDoubleSpinBox(); self.pay_amount.setRange(0,1e15); self.pay_amount.setDecimals(0); self.pay_amount.setGroupSeparatorShown(True)
        add=QPushButton("ثبت پرداخت"); add.setProperty("class","Primary"); add.clicked.connect(self.add_payment)
        for label,widget in [("تاریخ پرداخت",self.pay_date),("شرح",self.pay_desc),("شماره مرجع",self.pay_ref),("مبلغ (ریال)",self.pay_amount)]: f.addRow(label,widget)
        f.addRow(add); lay.addWidget(c)
        self.finance_table=QTableWidget(0,5); self.finance_table.setHorizontalHeaderLabels(["تاریخ","شرح","شماره مرجع","مبلغ (ریال)","شناسه"]); self.finance_table.setSelectionBehavior(QAbstractItemView.SelectRows); self.finance_table.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); lay.addWidget(self.finance_table,1)
        row=QHBoxLayout(); remove=QPushButton("حذف پرداخت انتخاب‌شده"); remove.setProperty("class","Secondary"); remove.clicked.connect(self.remove_payment); row.addWidget(remove); row.addStretch()
        self.finance_total=QLabel("مجموع پرداخت‌ها: 0 ریال"); row.addWidget(self.finance_total); lay.addLayout(row)

    def build_reports(self,lay):
        self.section_header(lay,"گزارش‌ها","خروجی‌های رسمی پروژه")
        c=Card(); g=QGridLayout(c)
        for i,(txt,fn) in enumerate([("گزارش برآورد Excel",self.export_excel),("گزارش برآورد PDF",self.export_pdf),("گزارش صورت‌وضعیت Excel",self.export_statement_excel),("گزارش صورت‌وضعیت PDF",self.export_statement_pdf)]):
            b=QPushButton(txt); b.setProperty("class","Primary" if i<2 else "Secondary"); b.clicked.connect(fn); g.addWidget(b,i//2,i%2)
        lay.addWidget(c); lay.addStretch()
    def build_settings(self,lay):
        self.section_header(lay,"تنظیمات","پشتیبان‌گیری و اطلاعات نسخه")
        c=Card(); f=QVBoxLayout(c); f.addWidget(QLabel(f"{APP_NAME} {APP_VERSION}")); f.addWidget(QLabel(f"پایگاه داده: {DB_PATH}")); b=QPushButton("پشتیبان‌گیری از پایگاه داده"); b.setProperty("class","Secondary"); b.clicked.connect(self.backup_db); f.addWidget(b); lay.addWidget(c); lay.addStretch()
    def goto(self,key):
        names={"dashboard":("داشبورد","کنترل مدیریتی پروژه فعال"),"projects":("پروژه و متره","مدیریت پروژه، قرارداد و متره"),"pricebook":("فهرست‌بها","جستجو و انتخاب ردیف‌های فهرست‌بها"),"analysis":("آنالیز بها","کنترل ترکیب هزینه"),"coeff":("ضرایب پیمان","مدیریت ضرایب قرارداد"),"statement":("صورت‌وضعیت","صدور و آرشیو صورت‌وضعیت"),"finance":("وضعیت مالی","پرداخت‌ها و شاخص‌های مالی پروژه"),"reports":("گزارش‌ها","خروجی Excel و PDF"),"settings":("تنظیمات","پشتیبان‌گیری و اطلاعات سیستم")}
        self.page_title.setText(names[key][0]); self.page_sub.setText(names[key][1]); self.stack.setCurrentWidget(self.pages[key])
        for k,b in self.nav_buttons: b.setProperty("active",k==key); b.style().unpolish(b); b.style().polish(b)
        if key=="finance": self.refresh_finance()
    def ensure_seed_pricebook(self):
        if not BUNDLED_PRICEBOOK.exists(): return
        if self.con.execute("SELECT COUNT(*) FROM price_items").fetchone()[0] == 0:
            try: import_price_csv(self.con,str(BUNDLED_PRICEBOOK))
            except Exception: pass
    def load_pricebook_meta(self):
        pls=price_lists(self.con)
        self.plyear.blockSignals(True); self.pldisc.blockSignals(True)
        self.plyear.clear(); self.pldisc.clear(); seen=set()
        for item in pls:
            self.plyear.addItem(str(item['year']),item['id'])
            if item['discipline'] not in seen:
                self.pldisc.addItem(item['discipline']); seen.add(item['discipline'])
        self.plyear.blockSignals(False); self.pldisc.blockSignals(False)
        for widget,slot in [(self.plyear,self.on_pricebook_filter_changed),(self.pldisc,self.on_pricebook_filter_changed)]:
            try: widget.currentIndexChanged.disconnect(slot)
            except (TypeError,RuntimeError): pass
            widget.currentIndexChanged.connect(slot)
        try: self.chfilter.currentIndexChanged.disconnect()
        except (TypeError,RuntimeError): pass
        self.chfilter.currentIndexChanged.connect(lambda _=None:self.refresh_pricebook())
        self.load_chapters()
        selected_id=self.project_id
        self.project_combo.blockSignals(True); self.project_combo.clear()
        for item in self.con.execute('SELECT id,name FROM projects ORDER BY id DESC').fetchall():
            self.project_combo.addItem(item['name'],item['id'])
        idx=self.project_combo.findData(selected_id) if selected_id else -1
        if idx<0 and self.project_combo.count(): idx=0
        self.project_combo.setCurrentIndex(idx)
        self.project_combo.blockSignals(False)
        self.project_id=int(self.project_combo.currentData()) if self.project_combo.currentData() is not None else None
        if self.project_id: self.load_project()
        else: self.clear_project_form()
    def load_chapters(self):
        self.chfilter.blockSignals(True); self.chfilter.clear(); self.chfilter.addItem("همه فصل‌ها","")
        if self.plyear.currentData():
            for c in chapters(self.con,int(self.plyear.currentData())): self.chfilter.addItem(f"{c['code']} - {c['title']}",c['code'])
        self.chfilter.blockSignals(False)
    def on_pricebook_filter_changed(self): self.load_chapters(); self.queue_price_search()
    def queue_price_search(self): self.search_timer.start()
    def refresh_pricebook(self):
        if not hasattr(self,'ptable'): return
        if not self.plyear.currentText() or not self.pldisc.currentText(): return
        rows=search_items(self.con,int(self.plyear.currentText()),self.pldisc.currentText(),self.psearch.text(),self.chfilter.currentData() or '',5000)
        self.current_price_rows = list(rows)
        self.ptable.setRowCount(0)
        for r in rows:
            i=self.ptable.rowCount(); self.ptable.insertRow(i); vals=[r['code'],r['description'],f"{r['chapter_code']} - {r['chapter_title']}",r['unit'],f"{r['unit_price']:,.0f}","موجود" if r['price_status']=='available' else "بدون قیمت"]
            for c,v in enumerate(vals): self.ptable.setItem(i,c,QTableWidgetItem(str(v)))
        self.statusBar().showMessage(f"{len(rows)} ردیف نمایش داده شد")
    def selected_price_rows(self):
        out=[]; seen=set()
        for idx in self.ptable.selectionModel().selectedRows():
            if idx.row()<len(self.current_price_rows):
                x=self.current_price_rows[idx.row()]
                if x['id'] not in seen: out.append(x); seen.add(x['id'])
        return out
    def show_price_details(self):
        rows=self.selected_price_rows()
        if not rows: return
        r=rows[0]; self.selected_item_id=int(r['id']); self.det_code.setText(str(r['code'])); self.det_ch.setText(f"فصل: {r['chapter_code']} - {r['chapter_title']}"); self.det_unit.setText(f"واحد: {r['unit']}"); self.det_price.setText(f"قیمت واحد: {r['unit_price']:,.0f} ریال" if float(r['unit_price'] or 0)>0 and r['price_status']=='available' else 'قیمت واحد: تعریف نشده / نامعتبر'); self.det_source.setText(f"منبع: {r['source'] or '-'}"); self.det_desc.setPlainText(r['description']); m=float(r['material_share'] or 0); l=float(r['labor_share'] or 0); e=float(r['equipment_share'] or 0); self.det_analysis.setText(f"آنالیز: مصالح {m:.1f}% | دستمزد {l:.1f}% | ماشین‌آلات {e:.1f}% | سایر {max(0,100-m-l-e):.1f}%"); self.analysis_summary.setText(f"ردیف انتخاب‌شده: {r['code']} — {r['description']}\nمصالح {m:.1f}% | دستمزد {l:.1f}% | ماشین‌آلات {e:.1f}% | سایر {max(0,100-m-l-e):.1f}%")
    def select_price(self):
        rows=self.selected_price_rows()
        if not rows: return
        r=rows[0]
        if float(r['unit_price'] or 0)<=0 or r['price_status']!='available':
            return QMessageBox.warning(self,'قیمت نامعتبر','این ردیف قیمت معتبر ندارد و به متره منتقل نشد.')
        self.selected_item_id=int(r['id']); self.selcode.setText(f"{r['code']} — {r['description'][:55]}"); self.goto('projects'); self.statusBar().showMessage('ردیف برای متره انتخاب شد')
    def compare_prices(self):
        rows=self.selected_price_rows();
        if len(rows)<2: return QMessageBox.information(self,'مقایسه','حداقل دو ردیف انتخاب کنید.')
        PriceCompareDialog(self,rows[:10]).exec()
    def edit_analysis(self):
        rows=self.selected_price_rows();
        if len(rows)!=1: return QMessageBox.information(self,'آنالیز بها','فقط یک ردیف انتخاب کنید.')
        d=AnalysisDialog(self,rows[0]);
        if d.exec()==QDialog.Accepted: update_analysis(self.con,rows[0]['id'],*d.values()); self.refresh_pricebook(); self.show_price_details()
    def save_project(self):
        name=self.pname.text().strip()
        if not name:
            QMessageBox.warning(self,'پروژه','نام پروژه را وارد کنید.'); self.pname.setFocus(); return
        values=(name,self.loc.text().strip(),self.contract.text().strip(),self.baseyear.value(),
                self.employer.text().strip(),self.consultant.text().strip(),self.contractor.text().strip(),
                self.contract_amount.value(),self.duration.value(),self.start_date.text().strip(),self.end_date.text().strip(),
                self.advance.value(),self.retention.value(),self.insurance.value(),self.tax.value())
        if self.project_id:
            self.con.execute('''UPDATE projects SET name=?,location=?,contract_no=?,base_year=?,employer=?,consultant=?,contractor=?,
                contract_amount=?,duration_days=?,start_date=?,end_date=?,advance_amount=?,retention_pct=?,insurance_pct=?,tax_pct=? WHERE id=?''',values+(self.project_id,))
        else:
            self.con.execute('''INSERT INTO projects(name,location,contract_no,base_year,employer,consultant,contractor,
                contract_amount,duration_days,start_date,end_date,advance_amount,retention_pct,insurance_pct,tax_pct)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',values)
            self.project_id=int(self.con.execute('SELECT last_insert_rowid()').fetchone()[0])
        self.con.commit(); saved_id=self.project_id
        self.load_pricebook_meta()
        idx=self.project_combo.findData(saved_id)
        if idx>=0: self.project_combo.setCurrentIndex(idx)
        self.project_id=saved_id; self.load_project(); self.statusBar().showMessage('پروژه و اطلاعات قرارداد ذخیره شد')
    def project_changed(self):
        data=self.project_combo.currentData()
        self.project_id=int(data) if data is not None else None
        if self.project_id: self.load_project()
        else: self.clear_project_form()
    def load_project(self):
        row=self.con.execute('SELECT * FROM projects WHERE id=?',(self.project_id,)).fetchone()
        if not row: return
        self.pname.setText(row['name'] or ''); self.loc.setText(row['location'] or ''); self.contract.setText(row['contract_no'] or '')
        self.baseyear.setValue(int(row['base_year'] or 1404))
        self.employer.setText(row['employer'] or ''); self.consultant.setText(row['consultant'] or ''); self.contractor.setText(row['contractor'] or '')
        self.contract_amount.setValue(float(row['contract_amount'] or 0)); self.duration.setValue(int(row['duration_days'] or 0))
        self.start_date.setText(row['start_date'] or ''); self.end_date.setText(row['end_date'] or '')
        self.advance.setValue(float(row['advance_amount'] or 0)); self.retention.setValue(float(row['retention_pct'] or 0))
        self.insurance.setValue(float(row['insurance_pct'] or 0)); self.tax.setValue(float(row['tax_pct'] or 0))
        self.refresh_takeoff(); self.load_coefficients(); self.refresh_statements(); self.refresh_finance(); self.apply_project_summary()
    def clear_project_form(self):
        for name in ['pname','loc','contract','employer','consultant','contractor','start_date','end_date']:
            widget=getattr(self,name,None)
            if widget: widget.clear()
        for name in ['contract_amount','duration','advance','retention','insurance','tax']:
            widget=getattr(self,name,None)
            if widget: widget.setValue(0 if name!='retention' else 5)
        if hasattr(self,'baseyear'): self.baseyear.setValue(1404)
        if hasattr(self,'tkt'): self.tkt.setRowCount(0)
        if hasattr(self,'ct'): self.ct.setRowCount(0)
        if hasattr(self,'st'): self.st.setRowCount(0)
        if hasattr(self,'statement_archive'): self.statement_archive.setRowCount(0)
        if hasattr(self,'finance_table'): self.finance_table.setRowCount(0)
        if hasattr(self,'project_total'): self.project_total.setText('جمع: 0 ریال')
        if hasattr(self,'sttotal'): self.sttotal.setText('جمع صورت‌وضعیت: 0 ریال')
        if hasattr(self,'finance_total'): self.finance_total.setText('مجموع پرداخت‌ها: 0 ریال')
        self.apply_project_summary()

    def new_project(self):
        self.project_id=None
        self.project_combo.blockSignals(True); self.project_combo.setCurrentIndex(-1); self.project_combo.blockSignals(False)
        self.clear_project_form(); self.goto('projects'); self.statusBar().showMessage('فرم پروژه جدید آماده است؛ پس از تکمیل، ذخیره پروژه را بزنید.')

    def add_takeoff(self):
        if not self.project_id:
            return QMessageBox.warning(self,'پروژه فعال','ابتدا یک پروژه ایجاد و ذخیره کنید.')
        if not self.selected_item_id:
            return QMessageBox.warning(self,'انتخاب ردیف','ابتدا از فهرست‌بها یک ردیف انتخاب کنید.')
        row=get_item(self.con,self.selected_item_id)
        if not row:
            return QMessageBox.warning(self,'فهرست‌بها','ردیف انتخاب‌شده در فهرست‌بها پیدا نشد.')
        if float(row['unit_price'] or 0)<=0 or row['price_status']!='available':
            return QMessageBox.warning(self,'قیمت نامعتبر','این ردیف قیمت معتبر ندارد؛ قبل از متره قیمت را در منبع داده اصلاح کنید.')
        self.con.execute('''INSERT INTO takeoff_lines(project_id,price_item_id,item_code,description,chapter_code,chapter_title,unit,quantity,unit_price,waste_pct,transport_pct)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)''',(self.project_id,row['id'],row['code'],row['description'],row['chapter_code'],row['chapter_title'],row['unit'],self.qty.value(),row['unit_price'],self.waste.value(),self.transport.value()))
        self.con.commit(); self.refresh_takeoff(); self.statusBar().showMessage('ردیف به متره پروژه فعال اضافه شد')
    def add_selected_prices_to_takeoff(self):
        rows=self.selected_price_rows()
        if not rows: return
        if not self.project_id: return QMessageBox.warning(self,'پروژه فعال','ابتدا یک پروژه ایجاد و ذخیره کنید.')
        invalid=[r for r in rows if float(r['unit_price'] or 0)<=0 or r['price_status']!='available']
        if invalid:
            return QMessageBox.warning(self,'ردیف بدون قیمت',f'{len(invalid)} ردیف قیمت معتبر ندارند. ابتدا قیمت آن‌ها را اصلاح کنید؛ هیچ ردیفی اضافه نشد.')
        for row in rows:
            self.con.execute('''INSERT INTO takeoff_lines(project_id,price_item_id,item_code,description,chapter_code,chapter_title,unit,quantity,unit_price)
                VALUES(?,?,?,?,?,?,?,?,?)''',(self.project_id,row['id'],row['code'],row['description'],row['chapter_code'],row['chapter_title'],row['unit'],1,row['unit_price']))
        self.con.commit(); self.refresh_takeoff(); self.goto('projects'); self.statusBar().showMessage(f'{len(rows)} ردیف به متره افزوده شد')
    def get_coefficients(self):
        if not self.project_id:return []
        return [dict(r) for r in self.con.execute('SELECT c.name,c.code,c.kind,COALESCE(pc.value,c.value) value,c.basis,pc.sequence,pc.enabled FROM project_coefficients pc JOIN coefficients c ON c.id=pc.coefficient_id WHERE pc.project_id=? AND pc.enabled=1 ORDER BY pc.sequence,c.id',(self.project_id,)).fetchall()]
    def refresh_takeoff(self):
        if not hasattr(self,'tkt') or not self.project_id:return
        rows=self.con.execute('SELECT * FROM takeoff_lines WHERE project_id=? ORDER BY id',(self.project_id,)).fetchall(); self.tkt.setRowCount(0); total=0
        for x in rows:
            b=calculate_line(x['quantity'],x['unit_price'],x['waste_pct'],x['transport_pct'],x['other_direct'],self.get_coefficients()); total+=b.final
            vals=[x['id'],x['item_code'],x['description'],x['chapter_title'],x['unit'],x['quantity'],x['unit_price'],b.base,b.coefficient_amount,b.escalation,b.final]
            i=self.tkt.rowCount(); self.tkt.insertRow(i)
            for c,v in enumerate(vals):
                text=f'{v:,.3f}' if c==5 else f'{v:,.0f}' if isinstance(v,(int,float)) and c>=6 else str(v)
                item=QTableWidgetItem(text)
                if c==0: item.setData(Qt.UserRole,int(x['id']))
                self.tkt.setItem(i,c,item)
        self.project_total.setText(f"جمع: {total:,.0f} ریال")
        self.apply_project_summary()

    def _selected_takeoff_id(self):
        row=self.tkt.currentRow() if hasattr(self,'tkt') else -1
        if row<0:return None
        item=self.tkt.item(row,0)
        return int(item.data(Qt.UserRole)) if item and item.data(Qt.UserRole) is not None else None

    def remove_takeoff(self):
        tid=self._selected_takeoff_id()
        if tid is None:return QMessageBox.information(self,'حذف ردیف','ابتدا یک ردیف را انتخاب کنید.')
        r=self.con.execute('SELECT item_code,description FROM takeoff_lines WHERE id=? AND project_id=?',(tid,self.project_id)).fetchone()
        if not r:return QMessageBox.warning(self,'خطا','ردیف انتخاب‌شده پیدا نشد.')
        archived=int(self.con.execute('SELECT COUNT(*) FROM statement_lines WHERE takeoff_line_id=?',(tid,)).fetchone()[0])
        message=f'آیا ردیف «{r["item_code"]} - {r["description"]}» از متره فعلی حذف شود؟'
        if archived: message+=f'\nاین ردیف در {archived} ردیف صورت‌وضعیت قبلی ثبت شده است؛ سوابق آرشیوی حفظ می‌شوند.'
        if QMessageBox.question(self,'حذف ردیف',message,QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:
            self.con.execute('DELETE FROM takeoff_lines WHERE id=? AND project_id=?',(tid,self.project_id)); self.con.commit(); self.refresh_takeoff(); self.refresh_statements(); self.statusBar().showMessage('ردیف حذف شد؛ سوابق صورت‌وضعیت حفظ شدند.')

    def edit_takeoff(self):
        tid=self._selected_takeoff_id()
        if tid is None:return QMessageBox.information(self,'ویرایش ردیف','ابتدا یک ردیف را انتخاب کنید.')
        x=self.con.execute('SELECT * FROM takeoff_lines WHERE id=? AND project_id=?',(tid,self.project_id)).fetchone()
        if not x:return QMessageBox.warning(self,'خطا','ردیف انتخاب‌شده پیدا نشد.')
        dlg=QDialog(self); dlg.setWindowTitle('ویرایش ردیف متره'); dlg.resize(520,420); form=QFormLayout(dlg)
        form.addRow('کد',QLabel(str(x['item_code'])))
        form.addRow('شرح',QLabel(str(x['description'])))
        qty=QDoubleSpinBox(); qty.setRange(0,1e12); qty.setDecimals(4); qty.setValue(float(x['quantity']))
        price=QDoubleSpinBox(); price.setRange(0,1e15); price.setDecimals(0); price.setValue(float(x['unit_price']))
        waste=QDoubleSpinBox(); waste.setRange(0,100); waste.setDecimals(3); waste.setValue(float(x['waste_pct']))
        transport=QDoubleSpinBox(); transport.setRange(0,100); transport.setDecimals(3); transport.setValue(float(x['transport_pct']))
        other=QDoubleSpinBox(); other.setRange(-1e15,1e15); other.setDecimals(0); other.setValue(float(x['other_direct']))
        preview=QLabel(); preview.setStyleSheet('font-weight:700; color:#0d5fa8;')
        form.addRow('مقدار',qty); form.addRow(f'قیمت واحد ({x["unit"]})',price); form.addRow('پرت %',waste); form.addRow('حمل %',transport); form.addRow('سایر مستقیم',other); form.addRow('پیش‌نمایش مبلغ',preview)
        def refresh_preview():
            b=calculate_line(qty.value(),price.value(),waste.value(),transport.value(),other.value(),self.get_coefficients()); preview.setText(f'{b.final:,.0f} ریال')
        for z in (qty,price,waste,transport,other): z.valueChanged.connect(refresh_preview)
        refresh_preview()
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); buttons.accepted.connect(dlg.accept); buttons.rejected.connect(dlg.reject); form.addRow(buttons)
        if dlg.exec()==QDialog.Accepted:
            reported=float(self.con.execute('SELECT COALESCE(MAX(quantity_to_date),0) FROM statement_lines WHERE takeoff_line_id=?',(tid,)).fetchone()[0])
            if qty.value()+1e-9 < reported:
                return QMessageBox.warning(self,'مقدار غیرمجاز',f'مقدار کل متره نمی‌تواند از مقدار صورت‌وضعیت‌شده تا تاریخ ({reported:,.4f}) کمتر باشد.')
            self.con.execute('UPDATE takeoff_lines SET quantity=?,unit_price=?,waste_pct=?,transport_pct=?,other_direct=? WHERE id=? AND project_id=?',(qty.value(),price.value(),waste.value(),transport.value(),other.value(),tid,self.project_id))
            self.con.commit(); self.refresh_takeoff(); self.apply_project_summary(); self.statusBar().showMessage('ردیف ویرایش شد')
    def load_coefficients(self):
        if not hasattr(self,'ct'): return
        self.ct.setRowCount(0); rows=self.con.execute('SELECT c.id,c.name,c.code,c.kind,COALESCE(pc.value,c.value) value,COALESCE(pc.sequence,10) seq FROM coefficients c LEFT JOIN project_coefficients pc ON pc.coefficient_id=c.id AND pc.project_id=? ORDER BY c.id',(self.project_id or -1,)).fetchall()
        for r in rows:
            i=self.ct.rowCount();self.ct.insertRow(i)
            for c,v in enumerate(r):self.ct.setItem(i,c,QTableWidgetItem(str(v)))
    def add_coefficient(self):
        if not self.project_id:
            return QMessageBox.warning(self,'ضریب پیمان','ابتدا یک پروژه را ایجاد و ذخیره کنید.')
        name=self.cname.text().strip()
        if not name: return QMessageBox.warning(self,'ضریب پیمان','نام ضریب را وارد کنید.')
        if self.ckind.currentText()=='percent' and not 0<=self.cvalue.value()<=1000:
            return QMessageBox.warning(self,'ضریب پیمان','مقدار درصد معتبر نیست.')
        try:
            self.con.execute('INSERT INTO coefficients(name,code,kind,value,basis) VALUES(?,?,?,?,?)',(name,self.ccode.text().strip(),self.ckind.currentText(),self.cvalue.value(),self.cbasis.currentText()))
            cid=self.con.execute('SELECT last_insert_rowid()').fetchone()[0]
            self.con.execute('INSERT INTO project_coefficients(project_id,coefficient_id,value,sequence,enabled) VALUES(?,?,?,?,1)',(self.project_id,cid,self.cvalue.value(),self.cseq.value()))
            self.con.commit(); self.load_coefficients(); self.refresh_takeoff(); self.apply_project_summary()
        except Exception as exc:
            self.con.rollback(); QMessageBox.critical(self,'خطا در ثبت ضریب',str(exc))
    def make_statement(self):
        if not self.project_id:
            return QMessageBox.warning(self,'صورت‌وضعیت','ابتدا یک پروژه فعال انتخاب کنید.')
        takeoff_rows=self.con.execute('SELECT * FROM takeoff_lines WHERE project_id=? ORDER BY id',(self.project_id,)).fetchall()
        if not takeoff_rows:
            return QMessageBox.information(self,'صورت‌وضعیت','پروژه ردیف متره ندارد.')
        previous_statement=self.con.execute('SELECT id FROM statements WHERE project_id=? AND statement_no<? ORDER BY statement_no DESC LIMIT 1',(self.project_id,self.sno.value())).fetchone()
        previous_quantities={}
        if previous_statement:
            for row in self.con.execute('SELECT takeoff_line_id,quantity_to_date FROM statement_lines WHERE statement_id=? AND takeoff_line_id IS NOT NULL',(previous_statement['id'],)).fetchall():
                previous_quantities[int(row['takeoff_line_id'])]=float(row['quantity_to_date'] or 0)
        dialog=StatementQuantityDialog(self,takeoff_rows,previous_quantities)
        if dialog.exec()!=QDialog.Accepted: return
        quantities=dialog.current_quantities()
        if not any(value>0 for value in quantities.values()):
            return QMessageBox.warning(self,'صورت‌وضعیت','حداقل مقدار جاری یک ردیف باید بیشتر از صفر باشد.')
        try:
            sid,total=create_statement(self.con,self.project_id,self.sno.value(),self.period.text(),self.adj.value()/100.0,
                                       coefficients=self.get_coefficients(),current_quantities=quantities)
            rows=statement_rows(self.con,sid); self.render_statement(rows,total); self.refresh_statements(); self.apply_project_summary()
            created_no=self.sno.value()
            next_no=int(self.con.execute('SELECT COALESCE(MAX(statement_no),0)+1 FROM statements WHERE project_id=?',(self.project_id,)).fetchone()[0])
            self.sno.setValue(min(9999,next_no))
            QMessageBox.information(self,'صورت‌وضعیت',f'صورت‌وضعیت شماره {created_no} ثبت شد.\nمبلغ این دوره: {total:,.0f} ریال')
        except Exception as exc:
            QMessageBox.critical(self,'خطا در صدور صورت‌وضعیت',str(exc))
    def render_statement(self,rows,total):
        self.st.setRowCount(0)
        for r in rows:
            i=self.st.rowCount();self.st.insertRow(i);vals=[r['item_code'],r['description'],r['quantity_current'],r['quantity_previous'],r['quantity_to_date'],r['unit_price'],r['amount_current'],r['adjustment_amount'],r['final_amount']]
            for c,v in enumerate(vals):self.st.setItem(i,c,QTableWidgetItem(f'{v:,.3f}' if c in (2,3,4) else f'{v:,.0f}' if isinstance(v,(int,float)) else str(v)))
        self.sttotal.setText(f"جمع صورت‌وضعیت: {total:,.0f} ریال")
    def refresh_statements(self):
        if not hasattr(self,'st') or not hasattr(self,'statement_archive'): return
        self.statement_archive.blockSignals(True); self.statement_archive.setRowCount(0)
        if self.project_id:
            rows=self.con.execute('''SELECT s.id,s.statement_no,s.period,s.created_at,COALESCE(SUM(sl.final_amount),0) total
                FROM statements s LEFT JOIN statement_lines sl ON sl.statement_id=s.id
                WHERE s.project_id=? GROUP BY s.id ORDER BY s.statement_no DESC''',(self.project_id,)).fetchall()
            for row in rows:
                i=self.statement_archive.rowCount(); self.statement_archive.insertRow(i)
                for col,value in enumerate([row['statement_no'],row['period'],f"{float(row['total']):,.0f}",row['created_at']]):
                    cell=QTableWidgetItem(str(value))
                    if col==0: cell.setData(Qt.UserRole,int(row['id']))
                    self.statement_archive.setItem(i,col,cell)
        self.statement_archive.blockSignals(False)
        if self.statement_archive.rowCount():
            self.statement_archive.selectRow(0); self.show_archived_statement()
        else:
            self.st.setRowCount(0); self.sttotal.setText('جمع صورت‌وضعیت: 0 ریال')

    def show_archived_statement(self):
        if not hasattr(self,'statement_archive') or not self.project_id: return
        row=self.statement_archive.currentRow()
        if row<0: return
        cell=self.statement_archive.item(row,0)
        if not cell: return
        sid=cell.data(Qt.UserRole)
        if sid is None: return
        rows=statement_rows(self.con,int(sid)); total=sum(float(x['final_amount'] or 0) for x in rows)
        self.render_statement(rows,total)
    def report_rows(self):
        out=[]
        if not self.project_id: return out
        coefficients=self.get_coefficients()
        for x in self.con.execute('SELECT * FROM takeoff_lines WHERE project_id=? ORDER BY id',(self.project_id,)).fetchall():
            b=calculate_line(x['quantity'],x['unit_price'],x['waste_pct'],x['transport_pct'],x['other_direct'],coefficients)
            out.append({'item_code':x['item_code'],'description':x['description'],'chapter_title':x['chapter_title'],'unit':x['unit'],
                        'quantity':x['quantity'],'unit_price':x['unit_price'],'other_direct':x['other_direct'],
                        'waste':b.waste,'transport':b.transport,'coefficient_amount':b.coefficient_amount,'escalation':b.escalation,
                        'base':b.base,'direct':b.direct,'final':b.final})
        return out
    def export_excel(self):
        p,_=QFileDialog.getSaveFileName(self,'ذخیره Excel','','Excel (*.xlsx)');
        if p:
            rows=self.report_rows(); build_estimate_xlsx(p,self.pname.text(),rows,sum(r['final'] for r in rows),self.get_coefficients()); QMessageBox.information(self,'گزارش','گزارش Excel ایجاد شد.')
    def export_pdf(self):
        p,_=QFileDialog.getSaveFileName(self,'ذخیره PDF','','PDF (*.pdf)');
        if p:
            rows=self.report_rows(); pdf_report(p,self.pname.text(),rows,sum(r['final'] for r in rows)); QMessageBox.information(self,'گزارش','گزارش PDF ایجاد شد.')
    def current_statement_rows(self):
        if not self.project_id: return None,[]
        statement_id=None
        if hasattr(self,'statement_archive') and self.statement_archive.currentRow()>=0:
            item=self.statement_archive.item(self.statement_archive.currentRow(),0)
            if item: statement_id=item.data(Qt.UserRole)
        if statement_id is None:
            row=self.con.execute('SELECT id FROM statements WHERE project_id=? ORDER BY statement_no DESC LIMIT 1',(self.project_id,)).fetchone()
            statement_id=row['id'] if row else None
        return (int(statement_id),statement_rows(self.con,int(statement_id))) if statement_id else (None,[])
    def export_statement_excel(self): self.export_statement_file('xlsx')
    def export_statement_pdf(self): self.export_statement_file('pdf')
    def export_statement_file(self,kind):
        sid,rows=self.current_statement_rows()
        if not sid: return QMessageBox.information(self,'صورت‌وضعیت','هنوز صورت‌وضعیتی ثبت نشده است.')
        path,_=QFileDialog.getSaveFileName(self,'خروجی صورت‌وضعیت','',f'{kind.upper()} (*.{kind})')
        if not path: return
        data=[]
        for row in rows:
            data.append({'item_code':row['item_code'],'description':row['description'],'chapter_title':row['chapter_title'],'unit':row['unit'],
                'quantity':row['quantity_current'],'unit_price':row['unit_price'],'final':row['final_amount'],
                'base':row['base_amount_current'],'waste':row['waste_amount_current'],'transport':row['transport_amount_current'],
                'coefficient_amount':row['coefficient_amount_current'],'escalation':row['adjustment_amount'],
                'other_direct':row['other_direct_amount_current']})
        total=sum(float(row['final']) for row in data)
        if kind=='xlsx': build_estimate_xlsx(path,self.pname.text(),data,total,self.get_coefficients(),statement='صورت‌وضعیت')
        else: pdf_report(path,self.pname.text(),data,total,statement='صورت‌وضعیت')
        QMessageBox.information(self,'گزارش','فایل صورت‌وضعیت ایجاد شد.')
    def apply_project_summary(self):
        if not hasattr(self,'metrics'): return
        if not self.project_id:
            for value in self.metrics: value.setText('0')
            if hasattr(self,'progress_fin'): self.progress_fin.setValue(0); self.dashboard_hint.setText('پروژه‌ای انتخاب نشده است.')
            return
        project=self.con.execute('SELECT * FROM projects WHERE id=?',(self.project_id,)).fetchone()
        if not project: return
        estimate=sum(row['final'] for row in self.report_rows())
        contract=float(project['contract_amount'] or 0)
        paid=float(self.con.execute('SELECT COALESCE(SUM(amount),0) FROM project_payments WHERE project_id=?',(self.project_id,)).fetchone()[0])
        count=int(self.con.execute('SELECT COUNT(*) FROM takeoff_lines WHERE project_id=?',(self.project_id,)).fetchone()[0])
        statements=int(self.con.execute('SELECT COUNT(*) FROM statements WHERE project_id=?',(self.project_id,)).fetchone()[0])
        latest=self.con.execute('SELECT id FROM statements WHERE project_id=? ORDER BY statement_no DESC LIMIT 1',(self.project_id,)).fetchone()
        latest_total=sum(float(row['final_amount'] or 0) for row in statement_rows(self.con,latest['id'])) if latest else 0.0
        basis=contract if contract>0 else estimate
        remaining=max(0.0,basis-paid)
        progress=(paid/basis*100.0) if basis>0 else 0.0
        values=[f'{contract:,.0f} ریال',f'{estimate:,.0f} ریال',f'{paid:,.0f} ریال',f'{remaining:,.0f} ریال',f'{min(100,progress):.1f}%',str(count),str(statements),f'{latest_total:,.0f} ریال']
        for label,value in zip(self.metrics,values): label.setText(value)
        if hasattr(self,'progress_fin'): self.progress_fin.setValue(int(min(100,max(0,progress))))
        if hasattr(self,'dashboard_hint'): self.dashboard_hint.setText(f"پروژه فعال: {project['name']} | برآورد: {estimate:,.0f} ریال | پرداخت: {paid:,.0f} ریال")
    def add_payment(self):
        if not self.project_id: return QMessageBox.warning(self,'وضعیت مالی','ابتدا یک پروژه فعال انتخاب کنید.')
        if self.pay_amount.value()<=0: return QMessageBox.warning(self,'وضعیت مالی','مبلغ پرداخت باید بیشتر از صفر باشد.')
        self.con.execute('INSERT INTO project_payments(project_id,payment_date,description,amount,reference_no) VALUES(?,?,?,?,?)',
            (self.project_id,self.pay_date.text().strip(),self.pay_desc.text().strip(),self.pay_amount.value(),self.pay_ref.text().strip()))
        self.con.commit(); self.pay_desc.clear(); self.pay_ref.clear(); self.pay_amount.setValue(0); self.refresh_finance(); self.apply_project_summary()

    def refresh_finance(self):
        if not hasattr(self,'finance_table'): return
        self.finance_table.setRowCount(0)
        if not self.project_id:
            self.finance_total.setText('مجموع پرداخت‌ها: 0 ریال'); return
        rows=self.con.execute('SELECT * FROM project_payments WHERE project_id=? ORDER BY payment_date DESC,id DESC',(self.project_id,)).fetchall()
        total=0.0
        for row in rows:
            i=self.finance_table.rowCount(); self.finance_table.insertRow(i); total+=float(row['amount'] or 0)
            values=[row['payment_date'],row['description'],row['reference_no'],f"{float(row['amount']):,.0f}",str(row['id'])]
            for col,value in enumerate(values):
                item=QTableWidgetItem(value)
                if col==4: item.setData(Qt.UserRole,int(row['id']))
                self.finance_table.setItem(i,col,item)
        self.finance_total.setText(f'مجموع پرداخت‌ها: {total:,.0f} ریال')

    def remove_payment(self):
        row=self.finance_table.currentRow()
        if row<0: return QMessageBox.information(self,'حذف پرداخت','ابتدا یک پرداخت را انتخاب کنید.')
        cell=self.finance_table.item(row,4); payment_id=cell.data(Qt.UserRole) if cell else None
        if payment_id is None: return
        if QMessageBox.question(self,'حذف پرداخت','این رکورد پرداخت حذف شود؟',QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes: return
        self.con.execute('DELETE FROM project_payments WHERE id=? AND project_id=?',(int(payment_id),self.project_id)); self.con.commit()
        self.refresh_finance(); self.apply_project_summary()

    def backup_db(self):
        p,_=QFileDialog.getSaveFileName(self,'پشتیبان‌گیری','','SQLite Database (*.db)');
        if p: self.con.commit(); shutil.copy2(DB_PATH,p); QMessageBox.information(self,'پشتیبان','فایل پشتیبان ذخیره شد.')
    def import_price(self):
        p,_=QFileDialog.getOpenFileName(self,'Import فهرست‌بها','','CSV (*.csv)');
        if p:
            try: n=import_price_csv(self.con,p); self.load_pricebook_meta(); self.refresh_pricebook(); QMessageBox.information(self,'Import',f'{n} ردیف وارد شد.')
            except Exception as e: QMessageBox.critical(self,'خطا',str(e))
