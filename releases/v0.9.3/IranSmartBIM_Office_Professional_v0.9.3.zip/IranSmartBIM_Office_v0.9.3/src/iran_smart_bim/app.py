import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QIcon
from .ui.main_window import MainWindow, QSS, BUNDLE_ROOT

def main():
    app=QApplication(sys.argv)
    app.setApplicationName('IranSmartBIM')
    app.setOrganizationName('IranSmartBIM')
    app.setLayoutDirection(Qt.RightToLeft)
    app.setFont(QFont('Segoe UI',10))
    icon=BUNDLE_ROOT/'assets'/'IranSmartBIM.ico'
    if icon.exists(): app.setWindowIcon(QIcon(str(icon)))
    app.setStyleSheet(QSS)
    w=MainWindow(); w.show()
    sys.exit(app.exec())
if __name__=='__main__': main()
