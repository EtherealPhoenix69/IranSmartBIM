Set shell = CreateObject("WScript.Shell")
base = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
exe = base & "\dist\IranSmartBIM.exe"
If CreateObject("Scripting.FileSystemObject").FileExists(exe) Then
  shell.Run Chr(34) & exe & Chr(34), 1, False
Else
  MsgBox "IranSmartBIM.exe پیدا نشد. ابتدا Build را انجام دهید.", 48, "IranSmartBIM"
End If
