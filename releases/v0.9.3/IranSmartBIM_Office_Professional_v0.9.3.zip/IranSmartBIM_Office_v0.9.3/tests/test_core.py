from __future__ import annotations

import sqlite3

import pytest

from iran_smart_bim.calculation import calculate_line, calculate_statement_line, statement_line
from iran_smart_bim.db import connect
from iran_smart_bim.services.importers import import_price_csv
from iran_smart_bim.services.pricebook import search_items, update_analysis, get_item
from iran_smart_bim.services.statements import create_statement, statement_rows, statement_total


def test_line():
    result = calculate_line(
        10, 100, 10, 5, 50,
        [{'kind': 'percent', 'value': 10, 'basis': 'direct', 'sequence': 10}],
        0,
    )
    assert result.base == 1000
    assert result.direct == 1200
    assert result.coefficient_amount == 120
    assert result.final == 1320


def test_legacy_statement_helper_is_backwards_compatible():
    result = statement_line(100, 70, 200, .1)
    assert result.current_qty == 30
    assert result.previous_qty == 70
    assert result.to_date_qty == 100
    assert result.final_amount == 6600


def _create_project_with_line(con, quantity=100, price=200, waste=10, transport=5, other=50):
    con.execute(
        "INSERT INTO projects(name,contract_amount) VALUES(?,?)",
        ('پروژه آزمایشی', 100000),
    )
    project_id = con.execute('SELECT last_insert_rowid()').fetchone()[0]
    con.execute(
        """INSERT INTO takeoff_lines(
            project_id,item_code,description,chapter_code,chapter_title,unit,
            quantity,unit_price,waste_pct,transport_pct,other_direct
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
        (project_id, '010101', 'آیتم آزمایشی', '01', 'عملیات خاکی', 'm3',
         quantity, price, waste, transport, other),
    )
    line_id = con.execute('SELECT last_insert_rowid()').fetchone()[0]
    con.commit()
    return project_id, line_id


def test_split_statements_reconcile_with_full_estimate(tmp_path):
    con = connect(tmp_path / 'project.db')
    project_id, line_id = _create_project_with_line(con)
    coefficients = [
        {'name': 'بالاسری', 'kind': 'percent', 'value': 10, 'basis': 'direct', 'sequence': 10, 'enabled': 1},
        {'name': 'کارگاه', 'kind': 'percent', 'value': 3, 'basis': 'direct', 'sequence': 20, 'enabled': 1},
    ]
    estimate = calculate_line(100, 200, 10, 5, 50, coefficients).final

    period_totals = []
    periods = [(1, 55), (2, 25), (3, 20)]
    for number, executed_this_period in periods:
        _, total = create_statement(
            con, project_id, number, f'دوره {number}',
            coefficients=coefficients,
            current_quantities={line_id: executed_this_period},
        )
        period_totals.append(total)

    assert sum(period_totals) == pytest.approx(estimate, rel=1e-10)
    final_rows = statement_rows(con, con.execute(
        'SELECT id FROM statements WHERE project_id=? AND statement_no=3', (project_id,)
    ).fetchone()['id'])
    assert final_rows[0]['quantity_previous'] == pytest.approx(80)
    assert final_rows[0]['quantity_current'] == pytest.approx(20)
    assert final_rows[0]['quantity_to_date'] == pytest.approx(100)
    assert final_rows[0]['base_amount_current'] == pytest.approx(4000)
    assert final_rows[0]['other_direct_amount_current'] == pytest.approx(10)
    assert final_rows[0]['coefficient_amount_current'] > 0


def test_statement_cannot_exceed_contract_quantity(tmp_path):
    con = connect(tmp_path / 'project.db')
    project_id, line_id = _create_project_with_line(con, quantity=10)
    with pytest.raises(ValueError, match='exceeds'):
        create_statement(con, project_id, 1, 'دوره 1', current_quantities={line_id: 11})


def test_archived_statement_rows_survive_takeoff_deletion(tmp_path):
    con = connect(tmp_path / 'project.db')
    project_id, line_id = _create_project_with_line(con)
    statement_id, _ = create_statement(
        con, project_id, 1, 'دوره 1', current_quantities={line_id: 10}
    )
    before = statement_rows(con, statement_id)[0]
    con.execute('DELETE FROM takeoff_lines WHERE id=?', (line_id,))
    con.commit()
    after_rows = statement_rows(con, statement_id)
    assert len(after_rows) == 1
    assert after_rows[0]['takeoff_line_id'] is None
    assert after_rows[0]['item_code'] == before['item_code'] == '010101'
    assert after_rows[0]['description'] == before['description'] == 'آیتم آزمایشی'
    assert statement_total(con, statement_id) == pytest.approx(before['final_amount'])


def test_regenerating_older_statement_is_blocked(tmp_path):
    con = connect(tmp_path / 'project.db')
    project_id, line_id = _create_project_with_line(con)
    create_statement(con, project_id, 1, 'دوره 1', current_quantities={line_id: 10})
    create_statement(con, project_id, 2, 'دوره 2', current_quantities={line_id: 10})
    with pytest.raises(ValueError, match='دوره‌های بعدی'):
        create_statement(con, project_id, 1, 'اصلاح دوره 1', current_quantities={line_id: 5})


def test_project_contract_and_payment_migrations(tmp_path):
    db_path = tmp_path / 'legacy.db'
    raw = sqlite3.connect(db_path)
    raw.execute('''CREATE TABLE projects(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, location TEXT DEFAULT '',
        contract_no TEXT DEFAULT '', base_year INTEGER, price_list_id INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')
    raw.execute("INSERT INTO projects(name) VALUES('پروژه قدیمی')")
    raw.commit(); raw.close()

    con = connect(db_path)
    project_columns = {row['name'] for row in con.execute('PRAGMA table_info(projects)').fetchall()}
    assert {'employer', 'consultant', 'contractor', 'contract_amount', 'duration_days',
            'start_date', 'end_date', 'advance_amount', 'retention_pct', 'insurance_pct', 'tax_pct'} <= project_columns
    con.execute(
        "INSERT INTO project_payments(project_id,payment_date,description,amount,reference_no) VALUES(?,?,?,?,?)",
        (1, '1405/01/01', 'پرداخت آزمایشی', 2500, 'REF-1'),
    )
    con.commit()
    assert con.execute('SELECT SUM(amount) FROM project_payments WHERE project_id=1').fetchone()[0] == 2500


def test_duplicate_price_codes_are_allowed(tmp_path):
    file_path = tmp_path / 'prices.csv'
    file_path.write_text(
        'year,discipline,title,bulletin_no,issue_date,source,chapter,chapter_title,code,description,unit,unit_price\n'
        '1404,ابنیه,فهرست,,,,01,فصل 01,010201,شرح اول,متر طول,100\n'
        '1404,ابنیه,فهرست,,,,01,فصل 01,010201,شرح دوم,متر طول,200\n',
        encoding='utf-8',
    )
    con = connect(tmp_path / 'prices.db')
    assert import_price_csv(con, str(file_path)) == 2
    assert con.execute('SELECT COUNT(*) FROM price_items').fetchone()[0] == 2


def test_pricebook_search_returns_analysis_fields(tmp_path):
    file_path = tmp_path / 'prices.csv'
    file_path.write_text(
        'year,discipline,title,bulletin_no,issue_date,source,chapter,chapter_title,code,description,unit,unit_price\n'
        '1404,ابنیه,فهرست,,,,01,فصل 01,010201,شرح اول,متر طول,100\n'
        '1404,ابنیه,فهرست,,,,01,فصل 01,010202,شرح دوم,متر طول,200\n',
        encoding='utf-8',
    )
    con = connect(tmp_path / 'prices.db')
    import_price_csv(con, str(file_path))
    rows = search_items(con, 1404, 'ابنیه', 'شرح')
    assert len(rows) == 2 and 'material_share' in rows[0].keys()
    update_analysis(con, rows[0]['id'], 55, 35, 10)
    item = get_item(con, rows[0]['id'])
    assert item['material_share'] == 55
    assert item['labor_share'] == 35
    assert item['equipment_share'] == 10


def test_official_abniyeh_1404_file_imports_all_rows():
    from pathlib import Path
    source = Path(__file__).resolve().parents[1] / 'data' / 'price_items_abniyeh_1404.csv'
    if not source.exists():
        pytest.skip('Official pricebook CSV is not included in this source checkout.')
    con = connect(':memory:')
    imported = import_price_csv(con, str(source))
    rows = search_items(con, 1404, 'ابنیه')
    assert imported == 1565
    assert len(rows) == 1565


def test_legacy_pay_date_column_is_migrated_without_losing_payments(tmp_path):
    db_path = tmp_path / 'payments_legacy.db'
    raw = sqlite3.connect(db_path)
    raw.execute('CREATE TABLE projects(id INTEGER PRIMARY KEY, name TEXT NOT NULL)')
    raw.execute("INSERT INTO projects(id,name) VALUES(1,'پروژه قدیمی')")
    raw.execute('''CREATE TABLE project_payments(
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
        pay_date TEXT NOT NULL, amount REAL NOT NULL DEFAULT 0,
        description TEXT DEFAULT '', reference_no TEXT DEFAULT ''
    )''')
    raw.execute("INSERT INTO project_payments(project_id,pay_date,amount,description) VALUES(1,'1404/02/01',5000,'پرداخت قدیمی')")
    raw.commit(); raw.close()

    con = connect(db_path)
    columns = {row['name'] for row in con.execute('PRAGMA table_info(project_payments)').fetchall()}
    assert 'payment_date' in columns
    assert 'pay_date' not in columns
    row = con.execute('SELECT payment_date,amount,description FROM project_payments WHERE project_id=1').fetchone()
    assert row['payment_date'] == '1404/02/01'
    assert row['amount'] == 5000
    assert row['description'] == 'پرداخت قدیمی'


def test_statement_period_allocates_fixed_other_direct_proportionally(tmp_path):
    con = connect(tmp_path / 'project.db')
    project_id, line_id = _create_project_with_line(con, quantity=200, price=100, waste=0, transport=0, other=1000)
    expected = calculate_line(200, 100, 0, 0, 1000).final
    period_amounts = []
    for number, amount in [(1, 50), (2, 50), (3, 100)]:
        _, total = create_statement(
            con, project_id, number, f'دوره {number}',
            current_quantities={line_id: amount},
        )
        period_amounts.append(total)
    assert sum(period_amounts) == pytest.approx(expected)


def test_xlsx_and_pdf_reports_are_written(tmp_path):
    from iran_smart_bim.services.excel_report import build_estimate_xlsx
    from iran_smart_bim.services.reporting import pdf_report
    rows = [{
        'item_code': '010101', 'description': 'آیتم آزمایشی ساختمان', 'chapter_title': 'عملیات خاکی',
        'unit': 'm3', 'quantity': 10, 'unit_price': 1000, 'base': 10000,
        'waste': 500, 'transport': 200, 'other_direct': 100, 'coefficient_amount': 1080,
        'escalation': 0, 'final': 11880,
    }]
    xlsx = tmp_path / 'estimate.xlsx'
    pdf = tmp_path / 'estimate.pdf'
    build_estimate_xlsx(xlsx, 'پروژه تست', rows, 11880, [])
    pdf_report(pdf, 'پروژه تست', rows, 11880)
    assert xlsx.exists() and xlsx.stat().st_size > 1000
    assert pdf.exists() and pdf.stat().st_size > 1000
