@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0dist\IranSmartBIM.exe" (
  start "" "%~dp0dist\IranSmartBIM.exe"
  exit /b 0
)
echo IranSmartBIM.exe is not built yet.
echo Run build_windows.ps1 once in PowerShell, then launch the EXE.
pause
