$ErrorActionPreference = 'Stop'
$exe = Join-Path $PSScriptRoot 'dist\IranSmartBIM.exe'
if (!(Test-Path $exe)) { Write-Host 'ابتدا Build را انجام دهید.' -ForegroundColor Yellow; exit 1 }
$desktop = [Environment]::GetFolderPath('Desktop')
$shortcut = Join-Path $desktop 'IranSmartBIM.lnk'
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($shortcut)
$s.TargetPath = $exe
$s.WorkingDirectory = Split-Path $exe
$s.IconLocation = "$exe,0"
$s.Description = 'IranSmartBIM - دفتر فنی و برآورد پیمانکاری'
$s.Save()
Write-Host "Shortcut created: $shortcut" -ForegroundColor Green
