$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

Write-Host 'Installing build dependencies...' -ForegroundColor Cyan
python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed.' }
python -m pip install -r requirements.txt pyinstaller
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }

if (Test-Path 'dist\IranSmartBIM.exe') { Remove-Item 'dist\IranSmartBIM.exe' -Force }
Write-Host 'Building IranSmartBIM.exe...' -ForegroundColor Cyan
python -m PyInstaller --noconfirm --clean pyinstaller.spec
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller returned a non-zero exit code.' }
if (-not (Test-Path 'dist\IranSmartBIM.exe')) { throw 'Build reported success but dist\IranSmartBIM.exe was not created.' }
Write-Host "`nBuild successful: $((Resolve-Path 'dist\IranSmartBIM.exe').Path)" -ForegroundColor Green
