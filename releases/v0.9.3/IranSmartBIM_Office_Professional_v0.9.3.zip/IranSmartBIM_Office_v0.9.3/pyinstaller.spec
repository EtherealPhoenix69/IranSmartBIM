from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules

# PyInstaller executes spec files with SPECPATH, not a reliable __file__.
ROOT = Path(SPECPATH).resolve()
SRC = ROOT / "src"
hidden = collect_submodules("reportlab") + collect_submodules("xlsxwriter")

a = Analysis(
    [str(SRC / "launcher.py")],
    pathex=[str(SRC)],
    binaries=[],
    datas=[
        (str(ROOT / "data" / "price_items_abniyeh_1404.csv"), "data"),
        (str(ROOT / "data" / "pricebook_1404_manifest.json"), "data"),
        (str(ROOT / "assets" / "IranSmartBIM.ico"), "assets"),
    ],
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="IranSmartBIM",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    icon=str(ROOT / "assets" / "IranSmartBIM.ico"),
)
